#include <nodes/oenne/main_12_params.h>

// DIMS
const char* main_12_dims_names_[] = {
    "input_0_dim_0"
    , "input_0_dim_1"
    , "input_0_dim_2"
    , "const_0_dim_0"
    , "const_0_dim_1"
    , "const_0_dim_2"
    , "const_0_dim_3"
    , "conv2d_out_h"
    , "conv2d_out_w"
};
MatchDim main_12_dims_[9+1] = {
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//1,
        .global_idx = -1,
        .curr_size = 4,
        .curr_max_size = 6
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//1,
        .global_idx = -1,
        .curr_size = 4,
        .curr_max_size = 6
    },
    (MatchDim){
        .size = 3,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 3,
        .curr_max_size = 3
    },
    (MatchDim){
        .size = 3,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 3,
        .curr_max_size = 3
    },
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 60,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 60,
        .curr_max_size = 60
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//0,
        .global_idx = 0,
        .curr_size = 4,
        .curr_max_size = 4
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//0,
        .global_idx = 0,
        .curr_size = 4,
        .curr_max_size = 4
    },
    // default dim
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    }
};

MatchDim* main_12_input_0_dim_0 = &(main_12_dims_[0]);
MatchDim* main_12_input_0_dim_1 = &(main_12_dims_[1]);
MatchDim* main_12_input_0_dim_2 = &(main_12_dims_[2]);
MatchDim* main_12_const_0_dim_0 = &(main_12_dims_[3]);
MatchDim* main_12_const_0_dim_1 = &(main_12_dims_[4]);
MatchDim* main_12_const_0_dim_2 = &(main_12_dims_[5]);
MatchDim* main_12_const_0_dim_3 = &(main_12_dims_[6]);
MatchDim* main_12_conv2d_out_h = &(main_12_dims_[7]);
MatchDim* main_12_conv2d_out_w = &(main_12_dims_[8]);
MatchDim* main_12_default = &(main_12_dims_[9]);

MatchDims main_12_dims_cnt_ = (MatchDims){
    .num_dims = 9,
    .dims_names = main_12_dims_names_,
    .get_dim = default_match_ctx_get_dim,
    .get_dim_idx = default_match_ctx_get_dim_idx,
    .dims = main_12_dims_
};


// TILES
MatchTensorTile main_12_input_0_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[1]),
        .size = 4,
        .max_size = 6,
        .start_idx = -1,
        .curr_idx = -1
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[2]),
        .size = 4,
        .max_size = 6,
        .start_idx = -1,
        .curr_idx = -1
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[1]),
        .size = 4,
        .max_size = 6,
        .start_idx = -1,
        .curr_idx = -1
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[2]),
        .size = 4,
        .max_size = 6,
        .start_idx = -1,
        .curr_idx = -1
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_12_input_0_tiles = (MatchTensorTile*)main_12_input_0_tiles_;
MatchTensorTile main_12_const_0_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_12_dims_[3]),
        .size = 3,
        .max_size = 3,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[4]),
        .size = 3,
        .max_size = 3,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[5]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[3]),
        .size = 3,
        .max_size = 3,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[4]),
        .size = 3,
        .max_size = 3,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[5]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_12_const_0_tiles = (MatchTensorTile*)main_12_const_0_tiles_;
MatchTensorTile main_12_const_1_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_12_const_1_tiles = (MatchTensorTile*)main_12_const_1_tiles_;
MatchTensorTile main_12_const_2_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_12_const_2_tiles = (MatchTensorTile*)main_12_const_2_tiles_;
MatchTensorTile main_12_cast_2_out_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[7]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[8]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[7]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[8]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_12_dims_[6]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_12_cast_2_out_tiles = (MatchTensorTile*)main_12_cast_2_out_tiles_;

const char* main_12_tensors_names_[] = {
    "input_0"
    , "const_0"
    , "const_1"
    , "const_2"
    , "cast_2_out"
};

unsigned int main_12_input_0_pts[2] = {0, 0};
unsigned int main_12_const_0_pts[2] = {0, 0};
unsigned int main_12_const_1_pts[2] = {0, 0};
unsigned int main_12_const_2_pts[2] = {0, 0};
unsigned int main_12_cast_2_out_pts[2] = {0, 0};

MatchTensor main_12_tensors_[5] = {
    (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_VAR_TENSOR,
        .pts = main_12_input_0_pts,
        .tiles = main_12_input_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_12_const_0_pts,
        .tiles = main_12_const_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_12_const_1_pts,
        .tiles = main_12_const_1_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_12_const_2_pts,
        .tiles = main_12_const_2_tiles_
    }
    , (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_OUT_TENSOR,
        .pts = main_12_cast_2_out_pts,
        .tiles = main_12_cast_2_out_tiles_
    }
};

MatchTensor* main_12_input_0 = &(main_12_tensors_[0]);
MatchTensor* main_12_const_0 = &(main_12_tensors_[1]);
MatchTensor* main_12_const_1 = &(main_12_tensors_[2]);
MatchTensor* main_12_const_2 = &(main_12_tensors_[3]);
MatchTensor* main_12_cast_2_out = &(main_12_tensors_[4]);

MatchTensors main_12_tensors_cnt_ = (MatchTensors){
    .num_tensors = 5,
    .tensors_names = main_12_tensors_names_,
    .get_tensor = default_match_ctx_get_tensor,
    .get_tensor_idx = default_match_ctx_get_tensor_idx,
    .tensors = main_12_tensors_
};

// ops
const char* main_12_ops_names_[] = {
    "conv2d"
    , "cast"
    , "multiply"
    , "add"
    , "right_shift"
    , "clip"
    , "cast_2"
};
MatchConv2DAttrs main_12_op_conv2d_attrs_ = (MatchConv2DAttrs){
    .idx = 0
    ,.strides = {1, 1}
    ,.kernel_layout = "HWIO"
    ,.data_layout = "NHWC"
    ,.padding = {1, 1, 1, 1}
    ,.kernel_size = {3, 3}
    ,.depthwise = 1
    ,.dilation = {1, 1}
    ,.groups = 60
};
MatchConv2DAttrs* main_12_conv2d_attrs = &(main_12_op_conv2d_attrs_);
MatchCastAttrs main_12_op_cast_attrs_ = (MatchCastAttrs){
    .idx = 1
};
MatchCastAttrs* main_12_cast_attrs = &(main_12_op_cast_attrs_);
MatchMultiplyAttrs main_12_op_multiply_attrs_ = (MatchMultiplyAttrs){
    .idx = 2
    ,.axis = 3
    ,.multiplier = 1
};
MatchMultiplyAttrs* main_12_multiply_attrs = &(main_12_op_multiply_attrs_);
MatchAddAttrs main_12_op_add_attrs_ = (MatchAddAttrs){
    .idx = 3
    ,.axis = 3
    ,.adder = 0
};
MatchAddAttrs* main_12_add_attrs = &(main_12_op_add_attrs_);
MatchRightShiftAttrs main_12_op_right_shift_attrs_ = (MatchRightShiftAttrs){
    .idx = 4
    ,.right_shift = 15
};
MatchRightShiftAttrs* main_12_right_shift_attrs = &(main_12_op_right_shift_attrs_);
MatchClipAttrs main_12_op_clip_attrs_ = (MatchClipAttrs){
    .idx = 5
    ,.clip_min = 0
    ,.clip_max = 255
};
MatchClipAttrs* main_12_clip_attrs = &(main_12_op_clip_attrs_);
MatchCastAttrs main_12_op_cast_2_attrs_ = (MatchCastAttrs){
    .idx = 6
};
MatchCastAttrs* main_12_cast_2_attrs = &(main_12_op_cast_2_attrs_);
MatchOp main_12_ops_[7] = {
    (MatchOp){
        .op_code = 5,
        .attrs = &main_12_op_conv2d_attrs_
    }
    , (MatchOp){
        .op_code = 7,
        .attrs = &main_12_op_cast_attrs_
    }
    , (MatchOp){
        .op_code = 10,
        .attrs = &main_12_op_multiply_attrs_
    }
    , (MatchOp){
        .op_code = 2,
        .attrs = &main_12_op_add_attrs_
    }
    , (MatchOp){
        .op_code = 9,
        .attrs = &main_12_op_right_shift_attrs_
    }
    , (MatchOp){
        .op_code = 8,
        .attrs = &main_12_op_clip_attrs_
    }
    , (MatchOp){
        .op_code = 7,
        .attrs = &main_12_op_cast_2_attrs_
    }
};
MatchOp* main_12_conv2d_op = &(main_12_ops_[0]);
MatchOp* main_12_cast_op = &(main_12_ops_[1]);
MatchOp* main_12_multiply_op = &(main_12_ops_[2]);
MatchOp* main_12_add_op = &(main_12_ops_[3]);
MatchOp* main_12_right_shift_op = &(main_12_ops_[4]);
MatchOp* main_12_clip_op = &(main_12_ops_[5]);
MatchOp* main_12_cast_2_op = &(main_12_ops_[6]);

MatchOps main_12_ops_cnt_ = (MatchOps){
    .num_ops = 7,
    .ops_names = main_12_ops_names_,
    .get_op = default_match_ctx_get_op,
    .get_op_idx = default_match_ctx_get_op_idx,
    .ops = main_12_ops_
};

volatile MatchCtx main_12_ctx_ = (MatchCtx){
    .ctx_extension = 0x0,
    .tensors = &main_12_tensors_cnt_,
    .ops = &main_12_ops_cnt_,
    .dims = &main_12_dims_cnt_,
    .exec_module = PULP_CLUSTER,
    .pattern_name = depthwise_conv2d
};

volatile MatchCtx* main_12_ctx = &main_12_ctx_;

volatile int main_12_block_0_loop_K_2_iter = 0;
volatile int main_12_block_0_loop_K_1_iter = 0;
volatile int main_12_block_0_loop_FX_iter = 0;
volatile int main_12_block_0_loop_FY_iter = 0;
volatile int main_12_block_0_loop_K_iter = 0;
volatile int main_12_block_0_loop_OX_iter = 0;
volatile int main_12_block_0_loop_OY_iter = 0;

// Node Profiling
volatile node_stats_t main_12_stats = {0};