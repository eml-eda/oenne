#include <nodes/oenne/main_12_params.h>

int8_t* main_12_const_0_data = NULL;
int* main_12_const_1_data = NULL;
int* main_12_const_2_data = NULL;
int* main_12_right_shift_arg_1_data = NULL;
