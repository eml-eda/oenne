#include <nodes/oenne/main_28_params.h>

// DIMS
const char* main_28_dims_names_[] = {
    "input_0_dim_0"
    , "input_0_dim_1"
    , "const_0_dim_0"
};
MatchDim main_28_dims_[3+1] = {
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 209,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 209,
        .curr_max_size = 209
    },
    (MatchDim){
        .size = 10,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 10,
        .curr_max_size = 10
    },
    // default dim
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    }
};

MatchDim* main_28_input_0_dim_0 = &(main_28_dims_[0]);
MatchDim* main_28_input_0_dim_1 = &(main_28_dims_[1]);
MatchDim* main_28_const_0_dim_0 = &(main_28_dims_[2]);
MatchDim* main_28_default = &(main_28_dims_[3]);

MatchDims main_28_dims_cnt_ = (MatchDims){
    .num_dims = 3,
    .dims_names = main_28_dims_names_,
    .get_dim = default_match_ctx_get_dim,
    .get_dim_idx = default_match_ctx_get_dim_idx,
    .dims = main_28_dims_
};


// TILES
MatchTensorTile main_28_input_0_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[1]),
        .size = 209,
        .max_size = 209,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[1]),
        .size = 209,
        .max_size = 209,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_28_input_0_tiles = (MatchTensorTile*)main_28_input_0_tiles_;
MatchTensorTile main_28_const_0_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[1]),
        .size = 209,
        .max_size = 209,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[1]),
        .size = 209,
        .max_size = 209,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_28_const_0_tiles = (MatchTensorTile*)main_28_const_0_tiles_;
MatchTensorTile main_28_add_arg_1_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_28_add_arg_1_tiles = (MatchTensorTile*)main_28_add_arg_1_tiles_;
MatchTensorTile main_28_add_out_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_28_dims_[2]),
        .size = 10,
        .max_size = 10,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_28_add_out_tiles = (MatchTensorTile*)main_28_add_out_tiles_;

const char* main_28_tensors_names_[] = {
    "input_0"
    , "const_0"
    , "add_arg_1"
    , "add_out"
};

unsigned int main_28_input_0_pts[2] = {0, 0};
unsigned int main_28_const_0_pts[2] = {0, 0};
unsigned int main_28_add_arg_1_pts[2] = {0, 0};
unsigned int main_28_add_out_pts[2] = {0, 0};

MatchTensor main_28_tensors_[4] = {
    (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_VAR_TENSOR,
        .pts = main_28_input_0_pts,
        .tiles = main_28_input_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_28_const_0_pts,
        .tiles = main_28_const_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_28_add_arg_1_pts,
        .tiles = main_28_add_arg_1_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_OUT_TENSOR,
        .pts = main_28_add_out_pts,
        .tiles = main_28_add_out_tiles_
    }
};

MatchTensor* main_28_input_0 = &(main_28_tensors_[0]);
MatchTensor* main_28_const_0 = &(main_28_tensors_[1]);
MatchTensor* main_28_add_arg_1 = &(main_28_tensors_[2]);
MatchTensor* main_28_add_out = &(main_28_tensors_[3]);

MatchTensors main_28_tensors_cnt_ = (MatchTensors){
    .num_tensors = 4,
    .tensors_names = main_28_tensors_names_,
    .get_tensor = default_match_ctx_get_tensor,
    .get_tensor_idx = default_match_ctx_get_tensor_idx,
    .tensors = main_28_tensors_
};

// ops
const char* main_28_ops_names_[] = {
    "dense"
    , "cast"
    , "add"
};
MatchDenseAttrs main_28_op_dense_attrs_ = (MatchDenseAttrs){
    .idx = 0
    ,.out_features = 10
    ,.inp_features = 209
};
MatchDenseAttrs* main_28_dense_attrs = &(main_28_op_dense_attrs_);
MatchCastAttrs main_28_op_cast_attrs_ = (MatchCastAttrs){
    .idx = 1
};
MatchCastAttrs* main_28_cast_attrs = &(main_28_op_cast_attrs_);
MatchAddAttrs main_28_op_add_attrs_ = (MatchAddAttrs){
    .idx = 2
    ,.axis = -1
    ,.adder = 0
};
MatchAddAttrs* main_28_add_attrs = &(main_28_op_add_attrs_);
MatchOp main_28_ops_[3] = {
    (MatchOp){
        .op_code = 0,
        .attrs = &main_28_op_dense_attrs_
    }
    , (MatchOp){
        .op_code = 7,
        .attrs = &main_28_op_cast_attrs_
    }
    , (MatchOp){
        .op_code = 2,
        .attrs = &main_28_op_add_attrs_
    }
};
MatchOp* main_28_dense_op = &(main_28_ops_[0]);
MatchOp* main_28_cast_op = &(main_28_ops_[1]);
MatchOp* main_28_add_op = &(main_28_ops_[2]);

MatchOps main_28_ops_cnt_ = (MatchOps){
    .num_ops = 3,
    .ops_names = main_28_ops_names_,
    .get_op = default_match_ctx_get_op,
    .get_op_idx = default_match_ctx_get_op_idx,
    .ops = main_28_ops_
};

volatile MatchCtx main_28_ctx_ = (MatchCtx){
    .ctx_extension = 0x0,
    .tensors = &main_28_tensors_cnt_,
    .ops = &main_28_ops_cnt_,
    .dims = &main_28_dims_cnt_,
    .exec_module = PULP_CLUSTER,
    .pattern_name = dense_out
};

volatile MatchCtx* main_28_ctx = &main_28_ctx_;

volatile int main_28_block_0_loop_K_1_iter = 0;
volatile int main_28_block_0_loop_C_iter = 0;
volatile int main_28_block_0_loop_K_iter = 0;

// Node Profiling
volatile node_stats_t main_28_stats = {0};