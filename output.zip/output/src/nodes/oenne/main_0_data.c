#include <nodes/oenne/main_0_params.h>

int8_t* main_0_const_0_data = NULL;
int* main_0_const_1_data = NULL;
int* main_0_const_2_data = NULL;
int* main_0_right_shift_arg_1_data = NULL;
