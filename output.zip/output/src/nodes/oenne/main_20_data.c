#include <nodes/oenne/main_20_params.h>

int8_t* main_20_const_0_data = NULL;
int* main_20_const_1_data = NULL;
int* main_20_const_2_data = NULL;
int* main_20_right_shift_arg_1_data = NULL;
