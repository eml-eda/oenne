#include <nodes/oenne/main_24_params.h>

int8_t* main_24_const_0_data = NULL;
int* main_24_const_1_data = NULL;
int* main_24_const_2_data = NULL;
int* main_24_right_shift_arg_1_data = NULL;
