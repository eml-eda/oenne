#include <nodes/oenne/main_16_params.h>

// DIMS
const char* main_16_dims_names_[] = {
    "input_0_dim_0"
    , "input_0_dim_1"
    , "input_0_dim_2"
    , "input_0_dim_3"
    , "const_0_dim_0"
    , "const_0_dim_1"
    , "const_0_dim_3"
};
MatchDim main_16_dims_[7+1] = {
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 4,
        .curr_max_size = 4
    },
    (MatchDim){
        .size = 4,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 4,
        .curr_max_size = 4
    },
    (MatchDim){
        .size = 60,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 60,
        .curr_max_size = 60
    },
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    },
    (MatchDim){
        .size = 121,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 121,
        .curr_max_size = 121
    },
    // default dim
    (MatchDim){
        .size = 1,
        .dynamic = 0,//1,
        .global_idx = 0,
        .curr_size = 1,
        .curr_max_size = 1
    }
};

MatchDim* main_16_input_0_dim_0 = &(main_16_dims_[0]);
MatchDim* main_16_input_0_dim_1 = &(main_16_dims_[1]);
MatchDim* main_16_input_0_dim_2 = &(main_16_dims_[2]);
MatchDim* main_16_input_0_dim_3 = &(main_16_dims_[3]);
MatchDim* main_16_const_0_dim_0 = &(main_16_dims_[4]);
MatchDim* main_16_const_0_dim_1 = &(main_16_dims_[5]);
MatchDim* main_16_const_0_dim_3 = &(main_16_dims_[6]);
MatchDim* main_16_default = &(main_16_dims_[7]);

MatchDims main_16_dims_cnt_ = (MatchDims){
    .num_dims = 7,
    .dims_names = main_16_dims_names_,
    .get_dim = default_match_ctx_get_dim,
    .get_dim_idx = default_match_ctx_get_dim_idx,
    .dims = main_16_dims_
};


// TILES
MatchTensorTile main_16_input_0_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[1]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[2]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[3]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[1]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[2]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[3]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_16_input_0_tiles = (MatchTensorTile*)main_16_input_0_tiles_;
MatchTensorTile main_16_const_0_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_16_dims_[4]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[5]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[3]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[4]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[5]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[3]),
        .size = 60,
        .max_size = 60,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_16_const_0_tiles = (MatchTensorTile*)main_16_const_0_tiles_;
MatchTensorTile main_16_const_1_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_16_const_1_tiles = (MatchTensorTile*)main_16_const_1_tiles_;
MatchTensorTile main_16_const_2_tiles_[4] = {
    (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_16_const_2_tiles = (MatchTensorTile*)main_16_const_2_tiles_;
MatchTensorTile main_16_cast_2_out_tiles_[8] = {
    (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[1]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[2]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[0]),
        .size = 1,
        .max_size = 1,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[1]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[2]),
        .size = 4,
        .max_size = 4,
        .start_idx = 0,
        .curr_idx = 0
    }
    , (MatchTensorTile){
        .dim = &(main_16_dims_[6]),
        .size = 121,
        .max_size = 121,
        .start_idx = 0,
        .curr_idx = 0
    }
};
MatchTensorTile* main_16_cast_2_out_tiles = (MatchTensorTile*)main_16_cast_2_out_tiles_;

const char* main_16_tensors_names_[] = {
    "input_0"
    , "const_0"
    , "const_1"
    , "const_2"
    , "cast_2_out"
};

unsigned int main_16_input_0_pts[2] = {0, 0};
unsigned int main_16_const_0_pts[2] = {0, 0};
unsigned int main_16_const_1_pts[2] = {0, 0};
unsigned int main_16_const_2_pts[2] = {0, 0};
unsigned int main_16_cast_2_out_pts[2] = {0, 0};

MatchTensor main_16_tensors_[5] = {
    (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_VAR_TENSOR,
        .pts = main_16_input_0_pts,
        .tiles = main_16_input_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_16_const_0_pts,
        .tiles = main_16_const_0_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_16_const_1_pts,
        .tiles = main_16_const_1_tiles_
    }
    , (MatchTensor){
        .num_dims = 2,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 32,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_CONST_TENSOR,
        .pts = main_16_const_2_pts,
        .tiles = main_16_const_2_tiles_
    }
    , (MatchTensor){
        .num_dims = 4,
        .num_tiles = 2,
        .curr_tile = 0,
        .bits = 8,
        .base_pt = 0x0,
        .pt = 0x0,
        .tensor_type = MATCH_OUT_TENSOR,
        .pts = main_16_cast_2_out_pts,
        .tiles = main_16_cast_2_out_tiles_
    }
};

MatchTensor* main_16_input_0 = &(main_16_tensors_[0]);
MatchTensor* main_16_const_0 = &(main_16_tensors_[1]);
MatchTensor* main_16_const_1 = &(main_16_tensors_[2]);
MatchTensor* main_16_const_2 = &(main_16_tensors_[3]);
MatchTensor* main_16_cast_2_out = &(main_16_tensors_[4]);

MatchTensors main_16_tensors_cnt_ = (MatchTensors){
    .num_tensors = 5,
    .tensors_names = main_16_tensors_names_,
    .get_tensor = default_match_ctx_get_tensor,
    .get_tensor_idx = default_match_ctx_get_tensor_idx,
    .tensors = main_16_tensors_
};

// ops
const char* main_16_ops_names_[] = {
    "conv2d"
    , "cast"
    , "multiply"
    , "add"
    , "right_shift"
    , "clip"
    , "cast_2"
};
MatchConv2DAttrs main_16_op_conv2d_attrs_ = (MatchConv2DAttrs){
    .idx = 0
    ,.strides = {1, 1}
    ,.kernel_layout = "HWIO"
    ,.data_layout = "NHWC"
    ,.padding = {0, 0, 0, 0}
    ,.kernel_size = {1, 1}
    ,.depthwise = 0
    ,.dilation = {1, 1}
    ,.groups = 1
};
MatchConv2DAttrs* main_16_conv2d_attrs = &(main_16_op_conv2d_attrs_);
MatchCastAttrs main_16_op_cast_attrs_ = (MatchCastAttrs){
    .idx = 1
};
MatchCastAttrs* main_16_cast_attrs = &(main_16_op_cast_attrs_);
MatchMultiplyAttrs main_16_op_multiply_attrs_ = (MatchMultiplyAttrs){
    .idx = 2
    ,.axis = 3
    ,.multiplier = 1
};
MatchMultiplyAttrs* main_16_multiply_attrs = &(main_16_op_multiply_attrs_);
MatchAddAttrs main_16_op_add_attrs_ = (MatchAddAttrs){
    .idx = 3
    ,.axis = 3
    ,.adder = 0
};
MatchAddAttrs* main_16_add_attrs = &(main_16_op_add_attrs_);
MatchRightShiftAttrs main_16_op_right_shift_attrs_ = (MatchRightShiftAttrs){
    .idx = 4
    ,.right_shift = 15
};
MatchRightShiftAttrs* main_16_right_shift_attrs = &(main_16_op_right_shift_attrs_);
MatchClipAttrs main_16_op_clip_attrs_ = (MatchClipAttrs){
    .idx = 5
    ,.clip_min = 0
    ,.clip_max = 255
};
MatchClipAttrs* main_16_clip_attrs = &(main_16_op_clip_attrs_);
MatchCastAttrs main_16_op_cast_2_attrs_ = (MatchCastAttrs){
    .idx = 6
};
MatchCastAttrs* main_16_cast_2_attrs = &(main_16_op_cast_2_attrs_);
MatchOp main_16_ops_[7] = {
    (MatchOp){
        .op_code = 5,
        .attrs = &main_16_op_conv2d_attrs_
    }
    , (MatchOp){
        .op_code = 7,
        .attrs = &main_16_op_cast_attrs_
    }
    , (MatchOp){
        .op_code = 10,
        .attrs = &main_16_op_multiply_attrs_
    }
    , (MatchOp){
        .op_code = 2,
        .attrs = &main_16_op_add_attrs_
    }
    , (MatchOp){
        .op_code = 9,
        .attrs = &main_16_op_right_shift_attrs_
    }
    , (MatchOp){
        .op_code = 8,
        .attrs = &main_16_op_clip_attrs_
    }
    , (MatchOp){
        .op_code = 7,
        .attrs = &main_16_op_cast_2_attrs_
    }
};
MatchOp* main_16_conv2d_op = &(main_16_ops_[0]);
MatchOp* main_16_cast_op = &(main_16_ops_[1]);
MatchOp* main_16_multiply_op = &(main_16_ops_[2]);
MatchOp* main_16_add_op = &(main_16_ops_[3]);
MatchOp* main_16_right_shift_op = &(main_16_ops_[4]);
MatchOp* main_16_clip_op = &(main_16_ops_[5]);
MatchOp* main_16_cast_2_op = &(main_16_ops_[6]);

MatchOps main_16_ops_cnt_ = (MatchOps){
    .num_ops = 7,
    .ops_names = main_16_ops_names_,
    .get_op = default_match_ctx_get_op,
    .get_op_idx = default_match_ctx_get_op_idx,
    .ops = main_16_ops_
};

volatile MatchCtx main_16_ctx_ = (MatchCtx){
    .ctx_extension = 0x0,
    .tensors = &main_16_tensors_cnt_,
    .ops = &main_16_ops_cnt_,
    .dims = &main_16_dims_cnt_,
    .exec_module = PULP_CLUSTER,
    .pattern_name = pointwise_conv2d
};

volatile MatchCtx* main_16_ctx = &main_16_ctx_;

volatile int main_16_block_0_loop_K_1_iter = 0;
volatile int main_16_block_0_loop_OX_1_iter = 0;
volatile int main_16_block_0_loop_C_iter = 0;
volatile int main_16_block_0_loop_OY_iter = 0;
volatile int main_16_block_0_loop_OX_iter = 0;

// Node Profiling
volatile node_stats_t main_16_stats = {0};