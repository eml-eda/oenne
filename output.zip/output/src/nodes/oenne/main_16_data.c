#include <nodes/oenne/main_16_params.h>

int8_t* main_16_const_0_data = NULL;
int* main_16_const_1_data = NULL;
int* main_16_const_2_data = NULL;
int* main_16_right_shift_arg_1_data = NULL;
