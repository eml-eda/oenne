#include <nodes/oenne/main_8_params.h>

int8_t* main_8_const_0_data = NULL;
int* main_8_const_1_data = NULL;
int* main_8_const_2_data = NULL;
int* main_8_right_shift_arg_1_data = NULL;
