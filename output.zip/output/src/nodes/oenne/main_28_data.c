#include <nodes/oenne/main_28_params.h>

int8_t* main_28_const_0_data = NULL;
int* main_28_add_arg_1_data = NULL;
