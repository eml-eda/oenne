#include <nodes/oenne/main_4_params.h>

int8_t* main_4_const_0_data = NULL;
int* main_4_const_1_data = NULL;
int* main_4_const_2_data = NULL;
int* main_4_right_shift_arg_1_data = NULL;
