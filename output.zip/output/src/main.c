#include <stdint.h>

#include <oenne/default_inputs.h>
#include <oenne/runtime.h>

// target specific inlcudes
    #include <pulp_utils/pulp_rt_profiler_wrapper.h>
    #include <pmsis.h>
    #include <pulp_cluster/cluster_dev.h>
    #include <pulp_mem/dma.h>
    #include <pulp_cluster/cluster.h>
    #include <pulp_mem/ram.h>


    volatile uint32_t pulp_cluster_args[16];


int main(int argc, char** argv){
    // target specific inits
        pulp_cluster_init();
    
    match_runtime_ctx match_ctx;

    // allocate match memory and external memory
    #if defined(__oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__) && __oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__>0
    void* match_ext_mem = pulp_init_ram(__oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__*1);
    int ext_mem_offset = 0;
    #endif
    #if defined(__oenne_GRAPH_PROFILE__) && __oenne_GRAPH_PROFILE__
    int start,end;
    start = start_match_perf_counter();
    #endif
    // setting inputs pointers and loading files
    #if !defined(__oenne_GRAPH_match_inp_0_FROM_EXTERNAL_MEM__) || !__oenne_GRAPH_match_inp_0_FROM_EXTERNAL_MEM__
    uint8_t* match_inp_0_pt = match_inp_0_default;
    #else
    void* match_inp_0_pt = match_ext_mem+ext_mem_offset;
    ext_mem_offset += 3072;
    pulp_load_file("oenne_match_inp_0_data.hex", match_inp_0_pt, 3072);
    #endif
    #if defined(__oenne_GRAPH_PROFILE__) && __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    int constants_loading_cycles = (int)(end - start);
    printf("Input files loading took %d cycles\n", constants_loading_cycles);
    #endif
    // setting outputs pointers
    #if !defined(__oenne_GRAPH_oenne_out_0_FROM_EXTERNAL_MEM__) || !__oenne_GRAPH_oenne_out_0_FROM_EXTERNAL_MEM__
        int* output_pt = malloc_wrapper(sizeof(int) * 10);
    #else
    void* output_pt = match_ext_mem+ext_mem_offset;
    ext_mem_offset += 40;
    #endif


    match_oenne_runtime(
        match_inp_0_pt,
            output_pt,
        &match_ctx
    );
    
    handle_int_classifier(
        output_pt,
        10,
        match_ctx.status
    );
    
            #if !defined(__oenne_GRAPH_oenne_out_0_FROM_EXTERNAL_MEM__) || !__oenne_GRAPH_oenne_out_0_FROM_EXTERNAL_MEM__
                free_wrapper(output_pt);
            #endif

    #if defined(__oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__) && __oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__>0
        pulp_shutdown_ram(match_ext_mem, __oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__*1);
    #endif
    // target specific cleaning functions
        pulp_cluster_close();
    return 0;
}