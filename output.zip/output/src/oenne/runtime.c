#include <oenne/runtime.h>



void match_oenne_runtime(
        uint8_t* match_inp_0_pt,
        int* output_pt,
    match_runtime_ctx* match_ctx){

        match_ctx->status = match_oenne_run_graph(
                match_inp_0_pt,
                 output_pt
        );

    return;
}




