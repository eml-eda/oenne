/*
 * Mohamed Amine Hamdi <mohamed.hamdi@polito.it>
 *
 * Copyright (C) 2024 Politecnico Di Torino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
*/


   


    // include params file
    #include "nodes/oenne/main_4_params.h"


    

    void tvmgen_oenne_match_main_4_inner(
            void* args
    )
    {
    
    


        // Rerieve tensor pointers from host trough known args location
        volatile unsigned *real_args = (unsigned int *) args;
        
            void* var_input_0_pt = (void*) real_args[0];            
            void* out_cast_2_out_pt = (void*) real_args[1];            
                void* main_4_const_0_pt = main_4_const_0_data;                void* main_4_const_1_pt = main_4_const_1_data;                void* main_4_const_2_pt = main_4_const_2_data;
    MatchCtx* ctx = main_4_ctx;

    
    


            cluster_lib_init(ctx);

        // Variable Tensors
            main_4_input_0->base_pt = var_input_0_pt;
            main_4_input_0->pt = var_input_0_pt;
            main_4_input_0->pts[L2_SHARED_MEM] = var_input_0_pt;
        // Output Tensors
            main_4_cast_2_out->base_pt = out_cast_2_out_pt;
            main_4_cast_2_out->pt = out_cast_2_out_pt;
            main_4_cast_2_out->pts[L2_SHARED_MEM] = out_cast_2_out_pt;
        // Constant Tensors
                main_4_const_0->base_pt = main_4_const_0_pt;
                main_4_const_0->pt = main_4_const_0_pt;
                main_4_const_0->pts[L2_SHARED_MEM] = main_4_const_0_pt;
                main_4_const_1->base_pt = main_4_const_1_pt;
                main_4_const_1->pt = main_4_const_1_pt;
                main_4_const_1->pts[L2_SHARED_MEM] = main_4_const_1_pt;
                main_4_const_2->base_pt = main_4_const_2_pt;
                main_4_const_2->pt = main_4_const_2_pt;
                main_4_const_2->pts[L2_SHARED_MEM] = main_4_const_2_pt;

    
    
    


    
    


        // Intermediate Tensors

                volatile void* L1_SCRATCHPAD_base_pt = init_l1_scratchpad_memory(ctx);
                int L1_SCRATCHPAD_curr_pt_offset = 0;
                        cluster_alloc_buffer(
                            "im2col",
                            L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset,
                            2160, L1_SCRATCHPAD, 0
                        );
                        L1_SCRATCHPAD_curr_pt_offset += (2160 + 63) & ~63; // align to 64 bytes

    
    
    


    int tile_mem_offset = 0;


        // block 0
            int block_0_loads = 0;
            
    

                

                    // compute the offset from the top level memory to obtain the correct tile for the transfer
                        int const_0_L1_SCRATCHPAD_tile_size = main_4_const_0_tiles_[L1_SCRATCHPAD*4+0].size * main_4_const_0_tiles_[L1_SCRATCHPAD*4+1].size * main_4_const_0_tiles_[L1_SCRATCHPAD*4+2].size * main_4_const_0_tiles_[L1_SCRATCHPAD*4+3].size;
                        tile_mem_offset = 0;
                        void* const_0_L2_SHARED_MEM_tile_pt = main_4_const_0->pts[L2_SHARED_MEM] + (tile_mem_offset>0?tile_mem_offset:0);
                    main_4_const_0->pts[L1_SCRATCHPAD] = L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset;
                    main_4_const_0->pt = main_4_const_0->pts[L1_SCRATCHPAD];
                    L1_SCRATCHPAD_curr_pt_offset += (const_0_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        // call API for pulp_cluster-specific memory transfer handling
                        
 handle_dma_transfer(
                            ctx,main_4_const_0,const_0_L2_SHARED_MEM_tile_pt,
                            main_4_const_0->pts[L1_SCRATCHPAD],
                            MATCH_SW_LOAD_TENSOR,
                            L2_SHARED_MEM,L1_SCRATCHPAD
                        );
                            block_0_loads++;
                    
                    // compute the offset from the top level memory to obtain the correct tile for the transfer
                        int const_1_L1_SCRATCHPAD_tile_size = main_4_const_1_tiles_[L1_SCRATCHPAD*2+1].size * 4.0;
                        tile_mem_offset = 0;
                        void* const_1_L2_SHARED_MEM_tile_pt = main_4_const_1->pts[L2_SHARED_MEM] + (tile_mem_offset>0?tile_mem_offset:0);
                    main_4_const_1->pts[L1_SCRATCHPAD] = L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset;
                    main_4_const_1->pt = main_4_const_1->pts[L1_SCRATCHPAD];
                    L1_SCRATCHPAD_curr_pt_offset += (const_1_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        // call API for pulp_cluster-specific memory transfer handling
                        
 handle_dma_transfer(
                            ctx,main_4_const_1,const_1_L2_SHARED_MEM_tile_pt,
                            main_4_const_1->pts[L1_SCRATCHPAD],
                            MATCH_SW_LOAD_TENSOR,
                            L2_SHARED_MEM,L1_SCRATCHPAD
                        );
                            block_0_loads++;
                    
                    // compute the offset from the top level memory to obtain the correct tile for the transfer
                        int const_2_L1_SCRATCHPAD_tile_size = main_4_const_2_tiles_[L1_SCRATCHPAD*2+1].size * 4.0;
                        tile_mem_offset = 0;
                        void* const_2_L2_SHARED_MEM_tile_pt = main_4_const_2->pts[L2_SHARED_MEM] + (tile_mem_offset>0?tile_mem_offset:0);
                    main_4_const_2->pts[L1_SCRATCHPAD] = L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset;
                    main_4_const_2->pt = main_4_const_2->pts[L1_SCRATCHPAD];
                    L1_SCRATCHPAD_curr_pt_offset += (const_2_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        // call API for pulp_cluster-specific memory transfer handling
                        
 handle_dma_transfer(
                            ctx,main_4_const_2,const_2_L2_SHARED_MEM_tile_pt,
                            main_4_const_2->pts[L1_SCRATCHPAD],
                            MATCH_SW_LOAD_TENSOR,
                            L2_SHARED_MEM,L1_SCRATCHPAD
                        );
                            block_0_loads++;
                    
            

            
    
    


            /*
                for(main_4_block_0_loop_OY_1_set();
                    main_4_block_0_loop_OY_1_end();
                    main_4_block_0_loop_OY_1_update()){
            */
            
    

                main_4_block_0_loop_OY_1_set();
            
    
    

            

            while(main_4_block_0_loop_OY_1_end()) {
            
    

                

                    // compute the offset from the top level memory to obtain the correct tile for the transfer
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].size = main_4_input_0_dim_1->curr_size; // this dim is not independent
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].max_size = main_4_input_0_dim_1->curr_max_size; // this dim is not independent
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].start_idx = main_4_input_0_dim_1->global_idx;
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].curr_idx = main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].start_idx;
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].size = main_4_input_0_dim_2->curr_size; // this dim is not independent
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].max_size = main_4_input_0_dim_2->curr_max_size; // this dim is not independent
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].start_idx = main_4_input_0_dim_2->global_idx;
                            main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].curr_idx = main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].start_idx;
                        int input_0_L1_SCRATCHPAD_tile_size = main_4_input_0_tiles_[L1_SCRATCHPAD*4+1].size * main_4_input_0_tiles_[L1_SCRATCHPAD*4+2].size * main_4_input_0_tiles_[L1_SCRATCHPAD*4+3].size;
                        tile_mem_offset = (int)((main_4_input_0_dim_1->global_idx>0?main_4_input_0_dim_1->global_idx-(main_4_input_0_tiles_[L2_SHARED_MEM*4+1].start_idx>0?main_4_input_0_tiles_[L2_SHARED_MEM*4+1].start_idx:0):0) * main_4_input_0_tiles_[L2_SHARED_MEM*4+2].size * main_4_input_0_tiles_[L2_SHARED_MEM*4+3].size);
                        void* input_0_L2_SHARED_MEM_tile_pt = main_4_input_0->pts[L2_SHARED_MEM] + (tile_mem_offset>0?tile_mem_offset:0);
                    main_4_input_0->pts[L1_SCRATCHPAD] = L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset;
                    main_4_input_0->pt = main_4_input_0->pts[L1_SCRATCHPAD];
                    L1_SCRATCHPAD_curr_pt_offset += (input_0_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        // call API for pulp_cluster-specific memory transfer handling
                        
 handle_dma_transfer(
                            ctx,main_4_input_0,input_0_L2_SHARED_MEM_tile_pt,
                            main_4_input_0->pts[L1_SCRATCHPAD],
                            MATCH_SW_LOAD_TENSOR,
                            L2_SHARED_MEM,L1_SCRATCHPAD
                        );
                            block_0_loads++;
                    
                    // compute the offset from the top level memory to obtain the correct tile for the transfer
                            main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+1].start_idx = main_4_conv2d_out_h->global_idx;
                            main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+1].curr_idx = main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+1].start_idx;
                        int cast_2_out_L1_SCRATCHPAD_tile_size = main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+1].size * main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+2].size * main_4_cast_2_out_tiles_[L1_SCRATCHPAD*4+3].size;
                        tile_mem_offset = (int)((main_4_conv2d_out_h->global_idx - main_4_cast_2_out_tiles_[L2_SHARED_MEM*4+1].start_idx) * main_4_cast_2_out_tiles_[L2_SHARED_MEM*4+2].size * main_4_cast_2_out_tiles_[L2_SHARED_MEM*4+3].size);
                        void* cast_2_out_L2_SHARED_MEM_tile_pt = main_4_cast_2_out->pts[L2_SHARED_MEM] + (tile_mem_offset>0?tile_mem_offset:0);
                    main_4_cast_2_out->pts[L1_SCRATCHPAD] = L1_SCRATCHPAD_base_pt + L1_SCRATCHPAD_curr_pt_offset;
                    main_4_cast_2_out->pt = main_4_cast_2_out->pts[L1_SCRATCHPAD];
                    L1_SCRATCHPAD_curr_pt_offset += (cast_2_out_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                    
            

            
    
    

                
        
    

            

                    // sync with the SW controlled transfers
                    if(block_0_loads) wait_l1_dma_transfers(ctx);
                    block_0_loads = 0;
                    
                    
                    
            

        
    
    

        
        


        
    

            

        
    
    

                pulp_nn_wrapper(ctx);

                    wait_pulp_nn_computation(ctx);

        

        
        
    

            

        
    
    

        
            

            
    

                

                        
                            L1_SCRATCHPAD_curr_pt_offset -= (input_0_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        
                            // call API for pulp_cluster-specific memory transfer handling
                            
 handle_dma_transfer(
                                ctx,main_4_cast_2_out,cast_2_out_L2_SHARED_MEM_tile_pt,
                                main_4_cast_2_out->pts[L1_SCRATCHPAD],
                                MATCH_SW_STORE_TENSOR,
                                L2_SHARED_MEM,L1_SCRATCHPAD
                            );
                                // sync after each single store as the SW transfer require...
                                wait_l1_dma_transfers(ctx);
                            L1_SCRATCHPAD_curr_pt_offset -= (cast_2_out_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                

            
    
    

            
                
    

                main_4_block_0_loop_OY_1_update();
                
    
    

                

                }
                
    

                main_4_block_0_loop_OY_1_reset();
                
    
    


            
    

                

                        
                            L1_SCRATCHPAD_curr_pt_offset -= (const_0_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        
                            L1_SCRATCHPAD_curr_pt_offset -= (const_1_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                        
                            L1_SCRATCHPAD_curr_pt_offset -= (const_2_L1_SCRATCHPAD_tile_size + 63) & ~63; // align to 64 bytes
                

            
    
    



    
    

                free_l1_scrachpad_memory(ctx,L1_SCRATCHPAD_base_pt);
            cluster_lib_cleanup(ctx);
    
    
    


    


    }



        int __attribute__ ((noinline)) tvmgen_oenne_match_main_4(
            void* var_input_0_pt,
            void* out_cast_2_out_pt
        ){
            unsigned int* args[2];
            args[0] = var_input_0_pt;
            args[1] = out_cast_2_out_pt;
            offload_to_pulp_cluster(main_4_ctx, tvmgen_oenne_match_main_4_inner, args);
            return 0;
        }
    
