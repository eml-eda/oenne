#include <oenne_graph.h>

// DLTensor declarations
DLTensor tvm_fallback_dltensor_0;
DLTensor tvm_fallback_dltensor_1;
// params of nodes
// void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handl
TVMValue tvm_fallback_args_[2];
int* tvm_fallback_arg_type_ids_;
void* tvm_fallback_out_ret_value_;
int* tvm_fallback_out_ret_tcode_;
void* tvm_fallback_resource_handle_;

// Perf counters kernels
#if __oenne_FALLBACK_GRAPH_PROFILE__
int constants_loading_cycles = 0;
// int sum_kernel_comp_cyc = 0;
int oenne_node_1_perf_cnt;
int oenne_node_2_perf_cnt;
int oenne_node_3_perf_cnt;
int oenne_node_4_perf_cnt;
int oenne_node_5_perf_cnt;
int oenne_node_6_perf_cnt;
int oenne_node_7_perf_cnt;
int oenne_node_8_perf_cnt;
int oenne_node_9_perf_cnt;
int oenne_node_10_perf_cnt;
int oenne_node_11_perf_cnt;
int oenne_node_12_perf_cnt;
int oenne_node_13_perf_cnt;
int oenne_node_14_perf_cnt;
// Perf Counters Mem Transfers
// int sum_mem_transfer_cyc = 0;
#endif


// GPIO variables
#ifdef USE_GPIO 
    pi_gpio_e gpio_test_0, gpio_test_1, gpio_test_2;
    #define TEST_GPIO_0 PI_GPIO_A89
    #define TEST_GPIO_1 PI_GPIO_A68
    #define TEST_GPIO_2 PI_GPIO_A52
    #define WRITE_GPIO(gpio_pin_x, x) {hal_compiler_barrier(); pi_gpio_pin_write(gpio_pin_x, x); hal_compiler_barrier();}
    #define SWITCH_GPIO(gpio_pin_x) {hal_compiler_barrier(); pi_gpio_pin_toggle(gpio_pin_x); hal_compiler_barrier();}
#endif

void match_oenne_graph_load_files(void* match_mem, void* match_ext_mem){
    
    //read all files into ext mem 
    return;
}

#if __oenne_FALLBACK_GRAPH_PROFILE__
void match_oenne_graph_profile_summary(void){
    printf("Node\tCycle\n");
    printf("[tvmgen_oenne_fused_layout_transform]\t%d\n", oenne_node_1_perf_cnt );
    printf("[tvmgen_oenne_match_main_0]\t%d\n", oenne_node_2_perf_cnt );
    printf("[tvmgen_oenne_fused_nn_max_pool2d]\t%d\n", oenne_node_3_perf_cnt );
    printf("[tvmgen_oenne_match_main_4]\t%d\n", oenne_node_4_perf_cnt );
    printf("[tvmgen_oenne_fused_nn_max_pool2d_1]\t%d\n", oenne_node_5_perf_cnt );
    printf("[tvmgen_oenne_match_main_8]\t%d\n", oenne_node_6_perf_cnt );
    printf("[tvmgen_oenne_fused_nn_max_pool2d_2]\t%d\n", oenne_node_7_perf_cnt );
    printf("[tvmgen_oenne_match_main_12]\t%d\n", oenne_node_8_perf_cnt );
    printf("[tvmgen_oenne_match_main_16]\t%d\n", oenne_node_9_perf_cnt );
    printf("[tvmgen_oenne_match_main_20]\t%d\n", oenne_node_10_perf_cnt );
    printf("[tvmgen_oenne_match_main_24]\t%d\n", oenne_node_11_perf_cnt );
    printf("[tvmgen_oenne_fused_nn_max_pool2d_3]\t%d\n", oenne_node_12_perf_cnt );
    printf("[tvmgen_oenne_fused_layout_transform_nn_batch_flatten]\t%d\n", oenne_node_13_perf_cnt );
    printf("[tvmgen_oenne_match_main_28]\t%d\n", oenne_node_14_perf_cnt );
    // printf("Total node cycles\t%d\n", sum_kernel_comp_cyc );
    // printf("Total memory cycles\t%d\n", sum_mem_transfer_cyc );

    printf("\nProfiling Mem Transfers Performance\n");
    printf("[file_constants_off_chip_loading LOAD]\tBytes:\t0\tCycles:\t%d\n", constants_loading_cycles);
}
#endif


int match_oenne_run_graph(
    uint8_t* match_inp_0_pt,
    int* oenne_out_0_pt
){


#if __oenne_GRAPH_PROFILE__ || __oenne_FALLBACK_GRAPH_PROFILE__
    int start,end;
    double time_elapsed_ms = 0.0f;
#endif
#ifdef USE_GPIO
    //struct pi_gpio_conf gpio_conf = {0};
    gpio_test_0 = TEST_GPIO_0;
    pi_pad_function_set(PI_PAD_089, 1);
    pi_gpio_pin_configure(gpio_test_0, PI_GPIO_OUTPUT);
    WRITE_GPIO(gpio_test_0, 1);

    gpio_test_1 = TEST_GPIO_1;
    pi_pad_function_set(PI_PAD_068, 1);
    pi_gpio_pin_configure(gpio_test_1, PI_GPIO_OUTPUT);
    WRITE_GPIO(gpio_test_1, 1);

    gpio_test_2 = TEST_GPIO_2;
    pi_pad_function_set(PI_PAD_052, 1);
    pi_gpio_pin_configure(gpio_test_2, PI_GPIO_OUTPUT);
    WRITE_GPIO(gpio_test_2, 1);
#endif
    void* match_ext_mem = NULL;
    void* match_mem = malloc_wrapper(__MATCH_MEM_SIZE__);
    if (!match_mem) {
        printf("Error: match_mem allocation failed\n");
        return -1;
    }
    match_set_match_mem_pt(match_mem);

    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    match_oenne_graph_load_files(match_mem, match_ext_mem);
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    constants_loading_cycles = (int)(end - start);
    #endif
    #ifdef USE_GPIO
    WRITE_GPIO(gpio_test_0, 0);
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_1: 'tvmgen_oenne_fused_layout_transform'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_inp_0_pt;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 15360;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_layout_transform(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_1_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_1_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_1 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_1 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 15360, __oenne_GRAPH_oenne_node_1_BYTES__, __oenne_GRAPH_oenne_node_1_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_2: 'tvmgen_oenne_match_main_0'\r\n");
    #endif


    main_0_const_0_data = main_0_const_0_data_;
    main_0_const_1_data = main_0_const_1_data_;
    main_0_const_2_data = main_0_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_0(
            match_mem + 15360
            ,match_mem + 0
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_2_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_2_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_2 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_2 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_2 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_2_BYTES__, __oenne_GRAPH_oenne_node_2_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_3: 'tvmgen_oenne_fused_nn_max_pool2d'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_mem + 0;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 15360;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_nn_max_pool2d(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_3_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_3_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_3 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_3 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 15360, __oenne_GRAPH_oenne_node_3_BYTES__, __oenne_GRAPH_oenne_node_3_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_4: 'tvmgen_oenne_match_main_4'\r\n");
    #endif


    main_4_const_0_data = main_4_const_0_data_;
    main_4_const_1_data = main_4_const_1_data_;
    main_4_const_2_data = main_4_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_4(
            match_mem + 15360
            ,match_mem + 0
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_4_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_4_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_4 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_4 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_4 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_4_BYTES__, __oenne_GRAPH_oenne_node_4_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_5: 'tvmgen_oenne_fused_nn_max_pool2d_1'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_mem + 0;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 8192;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_nn_max_pool2d_1(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_5_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_5_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_5 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_5 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 8192, __oenne_GRAPH_oenne_node_5_BYTES__, __oenne_GRAPH_oenne_node_5_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_6: 'tvmgen_oenne_match_main_8'\r\n");
    #endif


    main_8_const_0_data = main_8_const_0_data_;
    main_8_const_1_data = main_8_const_1_data_;
    main_8_const_2_data = main_8_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_8(
            match_mem + 8192
            ,match_mem + 0
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_6_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_6_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_6 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_6 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_6 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_6_BYTES__, __oenne_GRAPH_oenne_node_6_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_7: 'tvmgen_oenne_fused_nn_max_pool2d_2'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_mem + 0;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 3840;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_nn_max_pool2d_2(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_7_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_7_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_7 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_7 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 3840, __oenne_GRAPH_oenne_node_7_BYTES__, __oenne_GRAPH_oenne_node_7_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_8: 'tvmgen_oenne_match_main_12'\r\n");
    #endif


    main_12_const_0_data = main_12_const_0_data_;
    main_12_const_1_data = main_12_const_1_data_;
    main_12_const_2_data = main_12_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_12(
            match_mem + 3840
            ,match_mem + 4800
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_8_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_8_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_8 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_8 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_8 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 4800, __oenne_GRAPH_oenne_node_8_BYTES__, __oenne_GRAPH_oenne_node_8_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_9: 'tvmgen_oenne_match_main_16'\r\n");
    #endif


    main_16_const_0_data = main_16_const_0_data_;
    main_16_const_1_data = main_16_const_1_data_;
    main_16_const_2_data = main_16_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_16(
            match_mem + 4800
            ,match_mem + 0
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_9_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_9_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_9 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_9 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_9 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_9_BYTES__, __oenne_GRAPH_oenne_node_9_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_10: 'tvmgen_oenne_match_main_20'\r\n");
    #endif


    main_20_const_0_data = main_20_const_0_data_;
    main_20_const_1_data = main_20_const_1_data_;
    main_20_const_2_data = main_20_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_20(
            match_mem + 0
            ,match_mem + 3872
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_10_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_10_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_10 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_10 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_10 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 3872, __oenne_GRAPH_oenne_node_10_BYTES__, __oenne_GRAPH_oenne_node_10_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_11: 'tvmgen_oenne_match_main_24'\r\n");
    #endif


    main_24_const_0_data = main_24_const_0_data_;
    main_24_const_1_data = main_24_const_1_data_;
    main_24_const_2_data = main_24_const_2_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_24(
            match_mem + 3872
            ,match_mem + 0
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_11_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_11_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_11 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_11 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_11 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_11_BYTES__, __oenne_GRAPH_oenne_node_11_CHECKSUM__));
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_12: 'tvmgen_oenne_fused_nn_max_pool2d_3'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_mem + 0;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 3344;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_nn_max_pool2d_3(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_12_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_12_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_12 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_12 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 3344, __oenne_GRAPH_oenne_node_12_BYTES__, __oenne_GRAPH_oenne_node_12_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running TVM node oenne_node_13: 'tvmgen_oenne_fused_layout_transform_nn_batch_flatten'\r\n");
        #endif
    #endif


    // set correct pointers for node
    tvm_fallback_dltensor_0.data = match_mem + 3344;
    tvm_fallback_args_[0].v_handle = (void*)(&tvm_fallback_dltensor_0);
    tvm_fallback_dltensor_1.data = match_mem + 0;
    tvm_fallback_args_[1].v_handle = (void*)(&tvm_fallback_dltensor_1);
    #if __oenne_FALLBACK_GRAPH_PROFILE__
        start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_fused_layout_transform_nn_batch_flatten(tvm_fallback_args_, tvm_fallback_arg_type_ids_, 2,
                        tvm_fallback_out_ret_value_, tvm_fallback_out_ret_tcode_, tvm_fallback_resource_handle_)) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_FALLBACK_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_13_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_13_perf_cnt;
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] TVM node oenne_node_13 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
        #if __oenne_FALLBACK_GRAPH_DEBUG__
    printf("[oenne GRAPH] TVM node oenne_node_13 done, output differs from checksum by %d\n", match_byte_checksum_check(match_mem + 0, __oenne_GRAPH_oenne_node_13_BYTES__, __oenne_GRAPH_oenne_node_13_CHECKSUM__));
        #endif
    #endif
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] Running MATCH node oenne_node_14: 'tvmgen_oenne_match_main_28'\r\n");
    #endif


    main_28_const_0_data = main_28_const_0_data_;
    main_28_add_arg_1_data = main_28_add_arg_1_data_;
    #if __oenne_GRAPH_PROFILE__
    start = start_match_perf_counter();
    #endif
    if( tvmgen_oenne_match_main_28(
            match_mem + 0
            ,oenne_out_0_pt
        )
    ) return -1;
    #ifdef USE_GPIO
    SWITCH_GPIO(gpio_test_1);
    #endif
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    oenne_node_14_perf_cnt = (int)(end - start);
    // sum_kernel_comp_cyc += oenne_node_14_perf_cnt;
    // printf("[oenne GRAPH] MATCH node oenne_node_14 done, took %fms\n", time_elapsed_ms);
    #endif

    // Print profiling info
    #if __oenne_GRAPH_PROFILE__
    end = stop_match_perf_counter();
    time_elapsed_ms = ((double)(end - start)) ;
    printf("[oenne GRAPH] MATCH node oenne_node_14 done, took %fms\n", time_elapsed_ms);
    #endif

    // Check debug checksum
    #if __oenne_GRAPH_DEBUG__
    printf("[oenne GRAPH] MATCH node oenne_node_14 done, output differs from checksum by %d\n", match_byte_checksum_check(oenne_out_0_pt, __oenne_GRAPH_oenne_node_14_BYTES__, __oenne_GRAPH_oenne_node_14_CHECKSUM__));
    #endif

    #ifdef USE_GPIO
    WRITE_GPIO(gpio_test_0, 1);
    #endif

    #if __oenne_FALLBACK_GRAPH_PROFILE__
    match_oenne_graph_profile_summary();
    #endif
    // final cleanup
    free_wrapper(match_mem);

// Free external L3 memory pool

return 0;
}