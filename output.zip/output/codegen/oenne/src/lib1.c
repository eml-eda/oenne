// tvm target: c -keys=riscv_cpu,cpu -device=riscv_cpu
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_layout_transform_nn_batch_flatten(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_layout_transform_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_layout_transform_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  void* tvmgen_oenne_fused_layout_transform_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_oenne_fused_layout_transform_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  if (!(tvmgen_oenne_fused_layout_transform_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_layout_transform_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 32; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
        ((uint8_t*)T_layout_trans_1)[(((ax0_ax1_fused * 96) + (ax2 * 3)) + ax3_inner)] = ((uint8_t*)p0_1)[(((ax3_inner * 1024) + (ax0_ax1_fused * 32)) + ax2)];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_layout_transform_nn_batch_flatten(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t tensor_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* tensor = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_layout_transform_nn_batch_flatten_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_layout_transform_nn_batch_flatten_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* tensor_1 = (((DLTensor*)tensor)[0].data);
  void* tvmgen_oenne_fused_layout_transform_nn_batch_flatten_tensor_shape = (((DLTensor*)tensor)[0].shape);
  void* tvmgen_oenne_fused_layout_transform_nn_batch_flatten_tensor_strides = (((DLTensor*)tensor)[0].strides);
  if (!(tvmgen_oenne_fused_layout_transform_nn_batch_flatten_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_layout_transform_nn_batch_flatten_tensor_strides == NULL)) {
  }
  for (int32_t ax1_outer = 0; ax1_outer < 14; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      if (((ax1_outer * 16) + ax1_inner) < 209) {
        int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
        ((uint8_t*)tensor_1)[cse_var_1] = ((uint8_t*)p0_1)[cse_var_1];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t pool_max_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* pool_max = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* pool_max_1 = (((DLTensor*)pool_max)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_pool_max_shape = (((DLTensor*)pool_max)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_pool_max_strides = (((DLTensor*)pool_max)[0].strides);
  if (!(tvmgen_oenne_fused_nn_max_pool2d_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_nn_max_pool2d_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 16; ++ax2) {
      for (int32_t ax3_init = 0; ax3_init < 15; ++ax3_init) {
        ((uint8_t*)pool_max_1)[(((ax0_ax1_fused * 240) + (ax2 * 15)) + ax3_init)] = (uint8_t)0;
      }
      for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 4; ++rv0_rv1_fused) {
        for (int32_t ax3 = 0; ax3 < 15; ++ax3) {
          int32_t cse_var_1 = (((ax0_ax1_fused * 240) + (ax2 * 15)) + ax3);
          uint8_t v_ = ((uint8_t*)pool_max_1)[cse_var_1];
          uint8_t v__1 = ((uint8_t*)p0_1)[(((((ax0_ax1_fused * 960) + ((rv0_rv1_fused >> 1) * 480)) + (ax2 * 30)) + ((rv0_rv1_fused & 1) * 15)) + ax3)];
          ((uint8_t*)pool_max_1)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t pool_max_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* pool_max = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* pool_max_1 = (((DLTensor*)pool_max)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_1_pool_max_shape = (((DLTensor*)pool_max)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_1_pool_max_strides = (((DLTensor*)pool_max)[0].strides);
  if (!(tvmgen_oenne_fused_nn_max_pool2d_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_nn_max_pool2d_1_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 8; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_init = 0; ax3_init < 32; ++ax3_init) {
        ((uint8_t*)pool_max_1)[(((ax0_ax1_fused * 256) + (ax2 * 32)) + ax3_init)] = (uint8_t)0;
      }
      for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 4; ++rv0_rv1_fused) {
        for (int32_t ax3 = 0; ax3 < 32; ++ax3) {
          int32_t cse_var_1 = (((ax0_ax1_fused * 256) + (ax2 * 32)) + ax3);
          uint8_t v_ = ((uint8_t*)pool_max_1)[cse_var_1];
          uint8_t v__1 = ((uint8_t*)p0_1)[(((((ax0_ax1_fused * 1024) + ((rv0_rv1_fused >> 1) * 512)) + (ax2 * 64)) + ((rv0_rv1_fused & 1) * 32)) + ax3)];
          ((uint8_t*)pool_max_1)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t pool_max_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* pool_max = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_2_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_2_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* pool_max_1 = (((DLTensor*)pool_max)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_2_pool_max_shape = (((DLTensor*)pool_max)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_2_pool_max_strides = (((DLTensor*)pool_max)[0].strides);
  if (!(tvmgen_oenne_fused_nn_max_pool2d_2_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_nn_max_pool2d_2_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 4; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 4; ++ax2) {
      for (int32_t ax3_init = 0; ax3_init < 60; ++ax3_init) {
        ((uint8_t*)pool_max_1)[(((ax0_ax1_fused * 240) + (ax2 * 60)) + ax3_init)] = (uint8_t)0;
      }
      for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 4; ++rv0_rv1_fused) {
        for (int32_t ax3 = 0; ax3 < 60; ++ax3) {
          int32_t cse_var_1 = (((ax0_ax1_fused * 240) + (ax2 * 60)) + ax3);
          uint8_t v_ = ((uint8_t*)pool_max_1)[cse_var_1];
          uint8_t v__1 = ((uint8_t*)p0_1)[(((((ax0_ax1_fused * 960) + ((rv0_rv1_fused >> 1) * 480)) + (ax2 * 120)) + ((rv0_rv1_fused & 1) * 60)) + ax3)];
          ((uint8_t*)pool_max_1)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t pool_max_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* pool_max = (((TVMValue*)args)[1].v_handle);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_3_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_3_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* pool_max_1 = (((DLTensor*)pool_max)[0].data);
  void* tvmgen_oenne_fused_nn_max_pool2d_3_pool_max_shape = (((DLTensor*)pool_max)[0].shape);
  void* tvmgen_oenne_fused_nn_max_pool2d_3_pool_max_strides = (((DLTensor*)pool_max)[0].strides);
  if (!(tvmgen_oenne_fused_nn_max_pool2d_3_p0_strides == NULL)) {
  }
  if (!(tvmgen_oenne_fused_nn_max_pool2d_3_pool_max_strides == NULL)) {
  }
  for (int32_t ax3_outer_init = 0; ax3_outer_init < 11; ++ax3_outer_init) {
    for (int32_t ax3_inner_init = 0; ax3_inner_init < 19; ++ax3_inner_init) {
      ((uint8_t*)pool_max_1)[((ax3_outer_init * 19) + ax3_inner_init)] = (uint8_t)0;
    }
  }
  for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 16; ++rv0_rv1_fused) {
    for (int32_t ax3_outer = 0; ax3_outer < 11; ++ax3_outer) {
      for (int32_t ax3_inner = 0; ax3_inner < 19; ++ax3_inner) {
        int32_t cse_var_2 = (ax3_outer * 19);
        int32_t cse_var_1 = (cse_var_2 + ax3_inner);
        uint8_t v_ = ((uint8_t*)pool_max_1)[cse_var_1];
        uint8_t v__1 = ((uint8_t*)p0_1)[(((rv0_rv1_fused * 209) + cse_var_2) + ax3_inner)];
        ((uint8_t*)pool_max_1)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
      }
    }
  }
  return 0;
}

