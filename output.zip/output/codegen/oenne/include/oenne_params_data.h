#ifndef __MATCH_oenne_PARAMS_DATA_H__
#define __MATCH_oenne_PARAMS_DATA_H__

#include <match/types.h>
#include <nodes/oenne/main_0_data.h>
#include <nodes/oenne/main_4_data.h>
#include <nodes/oenne/main_8_data.h>
#include <nodes/oenne/main_12_data.h>
#include <nodes/oenne/main_16_data.h>
#include <nodes/oenne/main_20_data.h>
#include <nodes/oenne/main_24_data.h>
#include <nodes/oenne/main_28_data.h>

extern const int8_t main_0_const_0_data_[405];

extern const int main_0_const_1_data_[15];

extern const int main_0_const_2_data_[15];

extern const int8_t main_4_const_0_data_[4320];

extern const int main_4_const_1_data_[32];

extern const int main_4_const_2_data_[32];

extern const int8_t main_8_const_0_data_[17280];

extern const int main_8_const_1_data_[60];

extern const int main_8_const_2_data_[60];

extern const int8_t main_12_const_0_data_[540];

extern const int main_12_const_1_data_[60];

extern const int main_12_const_2_data_[60];

extern const int8_t main_16_const_0_data_[7260];

extern const int main_16_const_1_data_[121];

extern const int main_16_const_2_data_[121];

extern const int8_t main_20_const_0_data_[1089];

extern const int main_20_const_1_data_[121];

extern const int main_20_const_2_data_[121];

extern const int8_t main_24_const_0_data_[25289];

extern const int main_24_const_1_data_[209];

extern const int main_24_const_2_data_[209];

extern const int8_t main_28_const_0_data_[2090];

extern const int main_28_add_arg_1_data_[10];


#endif