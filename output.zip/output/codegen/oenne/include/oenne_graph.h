#ifndef __MATCH_oenne_RUN_GRAPH_H__
#define __MATCH_oenne_RUN_GRAPH_H__

#define nan 0.0

#include <match/types.h>

#define __MATCH_MEM_SIZE__ 19200


    #include <pulp_utils/pulp_rt_profiler_wrapper.h>
    #include <pmsis.h>
    #include <pulp_cluster/cluster_dev.h>
    #include <pulp_mem/dma.h>
    #include <pulp_cluster/cluster.h>
    #include <pulp_mem/ram.h>
#include <tvm/runtime/c_runtime_api.h>
#include <oenne_params_data.h>

/* 
 * TVM node function signature
 * void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle
 */

/* 
 * MATCH node function signature
 * type* inp_A, ..., type* inp_Z, type* out_A, ..., type* out_N
 */

#define __oenne_GRAPH_match_inp_0_FROM_EXTERNAL_MEM__ 0
#define __oenne_GRAPH_oenne_out_0_FROM_EXTERNAL_MEM__ 0

#define __oenne_GRAPH_INPUTS_OUTPUTS_EXT_MEM__ 0

// Profiling Flags
#define __oenne_GRAPH_PROFILE__ 0
#define __oenne_FALLBACK_GRAPH_PROFILE__ 0

// Debugging flags
#define __oenne_GRAPH_DEBUG__ 0
#define __oenne_FALLBACK_GRAPH_DEBUG__ 0
//gap measuriments flags
//#define USE_GPIO
#if __oenne_GRAPH_DEBUG__
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_1_CHECKSUM__ 376623
        #define __oenne_GRAPH_oenne_node_1_BYTES__ 3072
            #endif
        #define __oenne_GRAPH_oenne_node_2_CHECKSUM__ 362690
        #define __oenne_GRAPH_oenne_node_2_BYTES__ 15360
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_3_CHECKSUM__ 145536
        #define __oenne_GRAPH_oenne_node_3_BYTES__ 3840
            #endif
        #define __oenne_GRAPH_oenne_node_4_CHECKSUM__ 72178
        #define __oenne_GRAPH_oenne_node_4_BYTES__ 8192
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_5_CHECKSUM__ 35346
        #define __oenne_GRAPH_oenne_node_5_BYTES__ 2048
            #endif
        #define __oenne_GRAPH_oenne_node_6_CHECKSUM__ 41582
        #define __oenne_GRAPH_oenne_node_6_BYTES__ 3840
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_7_CHECKSUM__ 20101
        #define __oenne_GRAPH_oenne_node_7_BYTES__ 960
            #endif
        #define __oenne_GRAPH_oenne_node_8_CHECKSUM__ 30303
        #define __oenne_GRAPH_oenne_node_8_BYTES__ 960
        #define __oenne_GRAPH_oenne_node_9_CHECKSUM__ 29622
        #define __oenne_GRAPH_oenne_node_9_BYTES__ 1936
        #define __oenne_GRAPH_oenne_node_10_CHECKSUM__ 39495
        #define __oenne_GRAPH_oenne_node_10_BYTES__ 1936
        #define __oenne_GRAPH_oenne_node_11_CHECKSUM__ 14721
        #define __oenne_GRAPH_oenne_node_11_BYTES__ 3344
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_12_CHECKSUM__ 5339
        #define __oenne_GRAPH_oenne_node_12_BYTES__ 209
            #endif
            #if __oenne_FALLBACK_GRAPH_DEBUG__
        #define __oenne_GRAPH_oenne_node_13_CHECKSUM__ 5339
        #define __oenne_GRAPH_oenne_node_13_BYTES__ 209
            #endif
        #define __oenne_GRAPH_oenne_node_14_CHECKSUM__ 5031
        #define __oenne_GRAPH_oenne_node_14_BYTES__ 40
#endif

// Define node functions
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_layout_transform__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_0__
    // TVM Node function
        tvmgen_oenne_match_main_0(
            uint8_t* oenne_node_1_out_pt
            , uint8_t* oenne_node_2_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_nn_max_pool2d__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_4__
    // TVM Node function
        tvmgen_oenne_match_main_4(
            uint8_t* oenne_node_3_out_pt
            , uint8_t* oenne_node_4_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_nn_max_pool2d_1__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_8__
    // TVM Node function
        tvmgen_oenne_match_main_8(
            uint8_t* oenne_node_5_out_pt
            , uint8_t* oenne_node_6_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_nn_max_pool2d_2__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_12__
    // TVM Node function
        tvmgen_oenne_match_main_12(
            uint8_t* oenne_node_7_out_pt
            , uint8_t* oenne_node_8_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_16__
    // TVM Node function
        tvmgen_oenne_match_main_16(
            uint8_t* oenne_node_8_out_pt
            , uint8_t* oenne_node_9_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_20__
    // TVM Node function
        tvmgen_oenne_match_main_20(
            uint8_t* oenne_node_9_out_pt
            , uint8_t* oenne_node_10_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_24__
    // TVM Node function
        tvmgen_oenne_match_main_24(
            uint8_t* oenne_node_10_out_pt
            , uint8_t* oenne_node_11_out_pt
        );
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_nn_max_pool2d_3__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_nn_max_pool2d_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_fused_layout_transform_nn_batch_flatten__
    // TVM Node function
        #ifdef __cplusplus
        extern "C"
        #endif
        TVM_DLL int32_t tvmgen_oenne_fused_layout_transform_nn_batch_flatten(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
    // MATCH Node function
    #endif
    #ifndef __MATCH_oenne_RUN_GRAPH_tvmgen_oenne_match_main_28__
    // TVM Node function
        tvmgen_oenne_match_main_28(
            uint8_t* oenne_node_13_out_pt
            , int* oenne_out_0_pt
        );
    #endif

void match_oenne_graph_load_files(void* match_mem, void* match_ext_mem);

#if __oenne_FALLBACK_GRAPH_PROFILE__
void match_oenne_graph_profile_summary(void);
#endif

int match_oenne_run_graph(
    uint8_t* match_inp_0_pt,
    int* oenne_out_0_pt
);

// Define async graph runtime function
int match_oenne_run_graph_async(
    uint8_t* match_inp_0_pt,
    int* oenne_out_0_pt
);

// Model graph info
extern const int match_oenne_num_nodes;

// Keep track of the number of remaining parents to be executed for each node
extern int match_oenne_num_remaining_parents[14];

// Keep track of device busy status - TODO for multi-model support this should not-be per mode
extern int match_oenne_device_is_busy[2];

// Node execution complete callback - TODO for multi-model support this should not-be per model
void match_oenne_runtime_eoc_callback(int node_id);

// Graph execution finished flag
extern volatile int match_oenne_graph_execution_finished;


#endif