#ifndef __MATCH_TARGET_pulp_platform_H__
#define __MATCH_TARGET_pulp_platform_H__

#include <stdint.h>

#include <pulp_cluster.h>

#define __PULP_PLATFORM__NUM_EXEC_MODULE__ 1

#ifndef __L2_SHARED_MEM__
#define __L2_SHARED_MEM__
#define L2_SHARED_MEM 0
#endif

        #ifndef __L1_SCRATCHPAD__
        #define __L1_SCRATCHPAD__
        #define L1_SCRATCHPAD 1
        #endif

    extern volatile uint32_t pulp_cluster_args[16];

#ifndef __DENSE_OUT__
#define __DENSE_OUT__
#define dense_out 0
#endif
#ifndef __DENSE__
#define __DENSE__
#define dense 1
#endif
#ifndef __CONV2D__
#define __CONV2D__
#define conv2d 2
#endif
#ifndef __DEPTHWISE_CONV2D__
#define __DEPTHWISE_CONV2D__
#define depthwise_conv2d 3
#endif
#ifndef __POINTWISE_CONV2D__
#define __POINTWISE_CONV2D__
#define pointwise_conv2d 4
#endif
#ifndef __ADD_REQUANT__
#define __ADD_REQUANT__
#define add_requant 5
#endif

#endif