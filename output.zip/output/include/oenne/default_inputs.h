#ifndef __MATCH_oenne_DEFAULT_INPUTS_H__
#define __MATCH_oenne_DEFAULT_INPUTS_H__

#include <match/types.h>
#include <oenne/runtime.h>
#include <pulp_utils/pulp_rt_profiler_wrapper.h>
#include <pmsis.h>
#include <pulp_cluster/cluster_dev.h>
#include <pulp_mem/dma.h>
#include <pulp_cluster/cluster.h>
#include <pulp_mem/ram.h>

#if defined(__oenne_GRAPH_match_inp_0_UNUSED__)
extern const uint8_t * match_inp_0_default;
#elif !defined(__oenne_GRAPH_match_inp_0_FROM_EXTERNAL_MEM__) || !__oenne_GRAPH_match_inp_0_FROM_EXTERNAL_MEM__
extern const uint8_t  match_inp_0_default[3072];
#endif

#endif