#ifndef __MATCH_oenne_RUNTIME_H__
#define __MATCH_oenne_RUNTIME_H__

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <tvm_runtime.h>  // Include TVM runtime API

#include <match/ctx.h>

#include <oenne/default_inputs.h>

// Include model specific headers
        #include <oenne_graph.h>

// Target specific includes
#include <pulp_platform.h>
    #include <pulp_utils/pulp_rt_profiler_wrapper.h>
    #include <pmsis.h>
    #include <pulp_cluster/cluster_dev.h>
    #include <pulp_mem/dma.h>
    #include <pulp_cluster/cluster.h>
    #include <pulp_mem/ram.h>




    void match_oenne_runtime(
        uint8_t* match_inp_0_pt,
        int* output_pt,
    match_runtime_ctx* match_ctx);


#endif