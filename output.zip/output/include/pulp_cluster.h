#ifndef __MATCH_EXEC_MODULE_pulp_cluster_H__
#define __MATCH_EXEC_MODULE_pulp_cluster_H__

#include <pulp_platform.h>

#define PULP_CLUSTER 0



#endif