#ifndef __MATCH_NODE_DATA_tvmgen_oenne_match_main_4_H__
#define __MATCH_NODE_DATA_tvmgen_oenne_match_main_4_H__

extern int8_t* main_4_const_0_data;
extern int* main_4_const_1_data;
extern int* main_4_const_2_data;
extern int* main_4_right_shift_arg_1_data;

#endif