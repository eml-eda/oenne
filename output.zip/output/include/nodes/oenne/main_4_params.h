#ifndef __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_4_H__
#define __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_4_H__

#include <match/ctx.h>
#include <match/utils.h>
#include <match/types.h>

#include <pulp_platform.h>
#include <pulp_cluster.h>
#include <nodes/oenne/main_4_data.h>

// DIMS
extern const char* main_4_dims_names_[];
extern MatchDim main_4_dims_[9+1];
extern MatchDim* main_4_input_0_dim_0;
extern MatchDim* main_4_input_0_dim_1;
extern MatchDim* main_4_input_0_dim_2;
extern MatchDim* main_4_input_0_dim_3;
extern MatchDim* main_4_const_0_dim_0;
extern MatchDim* main_4_const_0_dim_1;
extern MatchDim* main_4_const_0_dim_3;
extern MatchDim* main_4_conv2d_out_h;
extern MatchDim* main_4_conv2d_out_w;
extern MatchDim* main_4_default;
extern MatchDims main_4_dims_cnt_;

// TILES
extern MatchTensorTile main_4_input_0_tiles_[8];
extern MatchTensorTile* main_4_input_0_tiles;
extern MatchTensorTile main_4_const_0_tiles_[8];
extern MatchTensorTile* main_4_const_0_tiles;
extern MatchTensorTile main_4_const_1_tiles_[4];
extern MatchTensorTile* main_4_const_1_tiles;
extern MatchTensorTile main_4_const_2_tiles_[4];
extern MatchTensorTile* main_4_const_2_tiles;
extern MatchTensorTile main_4_cast_2_out_tiles_[8];
extern MatchTensorTile* main_4_cast_2_out_tiles;


extern const char* main_4_tensors_names_[];
extern MatchTensor main_4_tensors_[5];
extern unsigned int main_4_input_0_pts[2];
extern MatchTensor* main_4_input_0;
extern unsigned int main_4_const_0_pts[2];
extern MatchTensor* main_4_const_0;
extern unsigned int main_4_const_1_pts[2];
extern MatchTensor* main_4_const_1;
extern unsigned int main_4_const_2_pts[2];
extern MatchTensor* main_4_const_2;
extern unsigned int main_4_cast_2_out_pts[2];
extern MatchTensor* main_4_cast_2_out;
extern MatchTensors main_4_tensors_cnt_;

// ops
extern const char* main_4_ops_names_[];
extern MatchOp main_4_ops_[7];
extern MatchConv2DAttrs main_4_op_conv2d_attrs_;
extern MatchConv2DAttrs* main_4_conv2d_attrs;
extern MatchOp* main_4_conv2d_op;
extern MatchCastAttrs main_4_op_cast_attrs_;
extern MatchCastAttrs* main_4_cast_attrs;
extern MatchOp* main_4_cast_op;
extern MatchMultiplyAttrs main_4_op_multiply_attrs_;
extern MatchMultiplyAttrs* main_4_multiply_attrs;
extern MatchOp* main_4_multiply_op;
extern MatchAddAttrs main_4_op_add_attrs_;
extern MatchAddAttrs* main_4_add_attrs;
extern MatchOp* main_4_add_op;
extern MatchRightShiftAttrs main_4_op_right_shift_attrs_;
extern MatchRightShiftAttrs* main_4_right_shift_attrs;
extern MatchOp* main_4_right_shift_op;
extern MatchClipAttrs main_4_op_clip_attrs_;
extern MatchClipAttrs* main_4_clip_attrs;
extern MatchOp* main_4_clip_op;
extern MatchCastAttrs main_4_op_cast_2_attrs_;
extern MatchCastAttrs* main_4_cast_2_attrs;
extern MatchOp* main_4_cast_2_op;
extern MatchOps main_4_ops_cnt_;

extern volatile MatchCtx main_4_ctx_;

extern volatile MatchCtx* main_4_ctx;

inline void main_4_update_input_0_dim_1(){
    main_4_input_0_dim_1->global_idx = 
    (1*main_4_conv2d_out_h->global_idx)
     + (1*main_4_const_0_dim_0->global_idx)
     + (-1*1)
    ;
    main_4_input_0_dim_1->curr_max_size = 
    (1*main_4_conv2d_out_h->curr_size)
     + (1*main_4_const_0_dim_0->curr_size)
     + (-1*1)
    ;
    // if input_0_dim_1 goes behind 0 it means there was padding so that shouldnt count for the size
    // same if it goes over the real size
    int max_size = (main_4_input_0_dim_1->global_idx + main_4_input_0_dim_1->curr_max_size) - main_4_input_0_dim_1->size;
    int min_size = -main_4_input_0_dim_1->global_idx;
    main_4_input_0_dim_1->curr_size = main_4_input_0_dim_1->curr_max_size - ((max_size>0?max_size:0) + (min_size>0?min_size:0));
}
inline void main_4_update_input_0_dim_2(){
    main_4_input_0_dim_2->global_idx = 
    (1*main_4_conv2d_out_w->global_idx)
     + (1*main_4_const_0_dim_1->global_idx)
     + (-1*1)
    ;
    main_4_input_0_dim_2->curr_max_size = 
    (1*main_4_conv2d_out_w->curr_size)
     + (1*main_4_const_0_dim_1->curr_size)
     + (-1*1)
    ;
    // if input_0_dim_2 goes behind 0 it means there was padding so that shouldnt count for the size
    // same if it goes over the real size
    int max_size = (main_4_input_0_dim_2->global_idx + main_4_input_0_dim_2->curr_max_size) - main_4_input_0_dim_2->size;
    int min_size = -main_4_input_0_dim_2->global_idx;
    main_4_input_0_dim_2->curr_size = main_4_input_0_dim_2->curr_max_size - ((max_size>0?max_size:0) + (min_size>0?min_size:0));
}


// loops iters counters
        extern volatile int main_4_block_0_loop_OY_1_iter;

        inline void main_4_block_0_loop_OY_1_set(){
            main_4_block_0_loop_OY_1_iter = 0;
            main_4_conv2d_out_h->curr_size = 8.0;
            main_4_conv2d_out_h->curr_max_size = 8.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_OY_1_reset(){
            // main_4_block_0_loop_OY_1_iter = 0;
            main_4_conv2d_out_h->global_idx -= 16.0;
            main_4_update_input_0_dim_1();
            return 0;
        }
        inline void main_4_block_0_loop_OY_1_update(){
            main_4_block_0_loop_OY_1_iter += 1;
            main_4_conv2d_out_h->global_idx += 8.0;
            // update the current size of the dim
            main_4_conv2d_out_h->curr_size = 8.0;
            main_4_conv2d_out_h->curr_max_size = 8.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_OY_1_end(){
            return main_4_block_0_loop_OY_1_iter < 2;
        }

        extern volatile int main_4_block_0_loop_K_2_iter;

        inline void main_4_block_0_loop_K_2_set(){
            main_4_block_0_loop_K_2_iter = 0;
            main_4_const_0_dim_3->curr_size = 8.0;
            main_4_const_0_dim_3->curr_max_size = 8.0;
        }
        inline int main_4_block_0_loop_K_2_reset(){
            // main_4_block_0_loop_K_2_iter = 0;
            main_4_const_0_dim_3->global_idx -= 32.0;
            return 0;
        }
        inline void main_4_block_0_loop_K_2_update(){
            main_4_block_0_loop_K_2_iter += 1;
            main_4_const_0_dim_3->global_idx += 8.0;
            // update the current size of the dim
            main_4_const_0_dim_3->curr_size = 8.0;
            main_4_const_0_dim_3->curr_max_size = 8.0;
        }
        inline int main_4_block_0_loop_K_2_end(){
            return main_4_block_0_loop_K_2_iter < 4;
        }

        extern volatile int main_4_block_0_loop_OX_1_iter;

        inline void main_4_block_0_loop_OX_1_set(){
            main_4_block_0_loop_OX_1_iter = 0;
            main_4_conv2d_out_w->curr_size = 2.0;
            main_4_conv2d_out_w->curr_max_size = 2.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_OX_1_reset(){
            // main_4_block_0_loop_OX_1_iter = 0;
            main_4_conv2d_out_w->global_idx -= 16.0;
            main_4_update_input_0_dim_2();
            return 0;
        }
        inline void main_4_block_0_loop_OX_1_update(){
            main_4_block_0_loop_OX_1_iter += 1;
            main_4_conv2d_out_w->global_idx += 2.0;
            // update the current size of the dim
            main_4_conv2d_out_w->curr_size = 2.0;
            main_4_conv2d_out_w->curr_max_size = 2.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_OX_1_end(){
            return main_4_block_0_loop_OX_1_iter < 8;
        }

        extern volatile int main_4_block_0_loop_K_1_iter;

        inline void main_4_block_0_loop_K_1_set(){
            main_4_block_0_loop_K_1_iter = 0;
            main_4_const_0_dim_3->curr_size = 4.0;
            main_4_const_0_dim_3->curr_max_size = 4.0;
        }
        inline int main_4_block_0_loop_K_1_reset(){
            // main_4_block_0_loop_K_1_iter = 0;
            main_4_const_0_dim_3->global_idx -= 8.0;
            return 0;
        }
        inline void main_4_block_0_loop_K_1_update(){
            main_4_block_0_loop_K_1_iter += 1;
            main_4_const_0_dim_3->global_idx += 4.0;
            // update the current size of the dim
            main_4_const_0_dim_3->curr_size = 4.0;
            main_4_const_0_dim_3->curr_max_size = 4.0;
        }
        inline int main_4_block_0_loop_K_1_end(){
            return main_4_block_0_loop_K_1_iter < 2;
        }

        extern volatile int main_4_block_0_loop_FX_iter;

        inline void main_4_block_0_loop_FX_set(){
            main_4_block_0_loop_FX_iter = 0;
            main_4_const_0_dim_1->curr_size = 1.0;
            main_4_const_0_dim_1->curr_max_size = 1.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_FX_reset(){
            // main_4_block_0_loop_FX_iter = 0;
            main_4_const_0_dim_1->global_idx -= 3.0;
            main_4_update_input_0_dim_2();
            return 0;
        }
        inline void main_4_block_0_loop_FX_update(){
            main_4_block_0_loop_FX_iter += 1;
            main_4_const_0_dim_1->global_idx += 1.0;
            // update the current size of the dim
            main_4_const_0_dim_1->curr_size = 1.0;
            main_4_const_0_dim_1->curr_max_size = 1.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_FX_end(){
            return main_4_block_0_loop_FX_iter < 3;
        }

        extern volatile int main_4_block_0_loop_FY_iter;

        inline void main_4_block_0_loop_FY_set(){
            main_4_block_0_loop_FY_iter = 0;
            main_4_const_0_dim_0->curr_size = 1.0;
            main_4_const_0_dim_0->curr_max_size = 1.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_FY_reset(){
            // main_4_block_0_loop_FY_iter = 0;
            main_4_const_0_dim_0->global_idx -= 3.0;
            main_4_update_input_0_dim_1();
            return 0;
        }
        inline void main_4_block_0_loop_FY_update(){
            main_4_block_0_loop_FY_iter += 1;
            main_4_const_0_dim_0->global_idx += 1.0;
            // update the current size of the dim
            main_4_const_0_dim_0->curr_size = 1.0;
            main_4_const_0_dim_0->curr_max_size = 1.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_FY_end(){
            return main_4_block_0_loop_FY_iter < 3;
        }

        extern volatile int main_4_block_0_loop_C_iter;

        inline void main_4_block_0_loop_C_set(){
            main_4_block_0_loop_C_iter = 0;
            main_4_input_0_dim_3->curr_size = 1.0;
            main_4_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_4_block_0_loop_C_reset(){
            // main_4_block_0_loop_C_iter = 0;
            main_4_input_0_dim_3->global_idx -= 15.0;
            return 0;
        }
        inline void main_4_block_0_loop_C_update(){
            main_4_block_0_loop_C_iter += 1;
            main_4_input_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_4_input_0_dim_3->curr_size = 1.0;
            main_4_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_4_block_0_loop_C_end(){
            return main_4_block_0_loop_C_iter < 15;
        }

        extern volatile int main_4_block_0_loop_OY_iter;

        inline void main_4_block_0_loop_OY_set(){
            main_4_block_0_loop_OY_iter = 0;
            main_4_conv2d_out_h->curr_size = 1.0;
            main_4_conv2d_out_h->curr_max_size = 1.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_OY_reset(){
            // main_4_block_0_loop_OY_iter = 0;
            main_4_conv2d_out_h->global_idx -= 8.0;
            main_4_update_input_0_dim_1();
            return 0;
        }
        inline void main_4_block_0_loop_OY_update(){
            main_4_block_0_loop_OY_iter += 1;
            main_4_conv2d_out_h->global_idx += 1.0;
            // update the current size of the dim
            main_4_conv2d_out_h->curr_size = 1.0;
            main_4_conv2d_out_h->curr_max_size = 1.0;
            main_4_update_input_0_dim_1();
        }
        inline int main_4_block_0_loop_OY_end(){
            return main_4_block_0_loop_OY_iter < 8;
        }

        extern volatile int main_4_block_0_loop_OX_iter;

        inline void main_4_block_0_loop_OX_set(){
            main_4_block_0_loop_OX_iter = 0;
            main_4_conv2d_out_w->curr_size = 1.0;
            main_4_conv2d_out_w->curr_max_size = 1.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_OX_reset(){
            // main_4_block_0_loop_OX_iter = 0;
            main_4_conv2d_out_w->global_idx -= 2.0;
            main_4_update_input_0_dim_2();
            return 0;
        }
        inline void main_4_block_0_loop_OX_update(){
            main_4_block_0_loop_OX_iter += 1;
            main_4_conv2d_out_w->global_idx += 1.0;
            // update the current size of the dim
            main_4_conv2d_out_w->curr_size = 1.0;
            main_4_conv2d_out_w->curr_max_size = 1.0;
            main_4_update_input_0_dim_2();
        }
        inline int main_4_block_0_loop_OX_end(){
            return main_4_block_0_loop_OX_iter < 2;
        }

        extern volatile int main_4_block_0_loop_K_iter;

        inline void main_4_block_0_loop_K_set(){
            main_4_block_0_loop_K_iter = 0;
            main_4_const_0_dim_3->curr_size = 1.0;
            main_4_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_4_block_0_loop_K_reset(){
            // main_4_block_0_loop_K_iter = 0;
            main_4_const_0_dim_3->global_idx -= 4.0;
            return 0;
        }
        inline void main_4_block_0_loop_K_update(){
            main_4_block_0_loop_K_iter += 1;
            main_4_const_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_4_const_0_dim_3->curr_size = 1.0;
            main_4_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_4_block_0_loop_K_end(){
            return main_4_block_0_loop_K_iter < 4;
        }


// Node Profiling
extern volatile node_stats_t main_4_stats;

#endif