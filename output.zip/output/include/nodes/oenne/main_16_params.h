#ifndef __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_16_H__
#define __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_16_H__

#include <match/ctx.h>
#include <match/utils.h>
#include <match/types.h>

#include <pulp_platform.h>
#include <pulp_cluster.h>
#include <nodes/oenne/main_16_data.h>

// DIMS
extern const char* main_16_dims_names_[];
extern MatchDim main_16_dims_[7+1];
extern MatchDim* main_16_input_0_dim_0;
extern MatchDim* main_16_input_0_dim_1;
extern MatchDim* main_16_input_0_dim_2;
extern MatchDim* main_16_input_0_dim_3;
extern MatchDim* main_16_const_0_dim_0;
extern MatchDim* main_16_const_0_dim_1;
extern MatchDim* main_16_const_0_dim_3;
extern MatchDim* main_16_default;
extern MatchDims main_16_dims_cnt_;

// TILES
extern MatchTensorTile main_16_input_0_tiles_[8];
extern MatchTensorTile* main_16_input_0_tiles;
extern MatchTensorTile main_16_const_0_tiles_[8];
extern MatchTensorTile* main_16_const_0_tiles;
extern MatchTensorTile main_16_const_1_tiles_[4];
extern MatchTensorTile* main_16_const_1_tiles;
extern MatchTensorTile main_16_const_2_tiles_[4];
extern MatchTensorTile* main_16_const_2_tiles;
extern MatchTensorTile main_16_cast_2_out_tiles_[8];
extern MatchTensorTile* main_16_cast_2_out_tiles;


extern const char* main_16_tensors_names_[];
extern MatchTensor main_16_tensors_[5];
extern unsigned int main_16_input_0_pts[2];
extern MatchTensor* main_16_input_0;
extern unsigned int main_16_const_0_pts[2];
extern MatchTensor* main_16_const_0;
extern unsigned int main_16_const_1_pts[2];
extern MatchTensor* main_16_const_1;
extern unsigned int main_16_const_2_pts[2];
extern MatchTensor* main_16_const_2;
extern unsigned int main_16_cast_2_out_pts[2];
extern MatchTensor* main_16_cast_2_out;
extern MatchTensors main_16_tensors_cnt_;

// ops
extern const char* main_16_ops_names_[];
extern MatchOp main_16_ops_[7];
extern MatchConv2DAttrs main_16_op_conv2d_attrs_;
extern MatchConv2DAttrs* main_16_conv2d_attrs;
extern MatchOp* main_16_conv2d_op;
extern MatchCastAttrs main_16_op_cast_attrs_;
extern MatchCastAttrs* main_16_cast_attrs;
extern MatchOp* main_16_cast_op;
extern MatchMultiplyAttrs main_16_op_multiply_attrs_;
extern MatchMultiplyAttrs* main_16_multiply_attrs;
extern MatchOp* main_16_multiply_op;
extern MatchAddAttrs main_16_op_add_attrs_;
extern MatchAddAttrs* main_16_add_attrs;
extern MatchOp* main_16_add_op;
extern MatchRightShiftAttrs main_16_op_right_shift_attrs_;
extern MatchRightShiftAttrs* main_16_right_shift_attrs;
extern MatchOp* main_16_right_shift_op;
extern MatchClipAttrs main_16_op_clip_attrs_;
extern MatchClipAttrs* main_16_clip_attrs;
extern MatchOp* main_16_clip_op;
extern MatchCastAttrs main_16_op_cast_2_attrs_;
extern MatchCastAttrs* main_16_cast_2_attrs;
extern MatchOp* main_16_cast_2_op;
extern MatchOps main_16_ops_cnt_;

extern volatile MatchCtx main_16_ctx_;

extern volatile MatchCtx* main_16_ctx;



// loops iters counters
        extern volatile int main_16_block_0_loop_K_1_iter;

        inline void main_16_block_0_loop_K_1_set(){
            main_16_block_0_loop_K_1_iter = 0;
            main_16_const_0_dim_3->curr_size = 1.0;
            main_16_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_K_1_reset(){
            // main_16_block_0_loop_K_1_iter = 0;
            main_16_const_0_dim_3->global_idx -= 121.0;
            return 0;
        }
        inline void main_16_block_0_loop_K_1_update(){
            main_16_block_0_loop_K_1_iter += 1;
            main_16_const_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_16_const_0_dim_3->curr_size = 1.0;
            main_16_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_K_1_end(){
            return main_16_block_0_loop_K_1_iter < 121;
        }

        extern volatile int main_16_block_0_loop_OX_1_iter;

        inline void main_16_block_0_loop_OX_1_set(){
            main_16_block_0_loop_OX_1_iter = 0;
            main_16_input_0_dim_2->curr_size = 2.0;
            main_16_input_0_dim_2->curr_max_size = 2.0;
        }
        inline int main_16_block_0_loop_OX_1_reset(){
            // main_16_block_0_loop_OX_1_iter = 0;
            main_16_input_0_dim_2->global_idx -= 4.0;
            return 0;
        }
        inline void main_16_block_0_loop_OX_1_update(){
            main_16_block_0_loop_OX_1_iter += 1;
            main_16_input_0_dim_2->global_idx += 2.0;
            // update the current size of the dim
            main_16_input_0_dim_2->curr_size = 2.0;
            main_16_input_0_dim_2->curr_max_size = 2.0;
        }
        inline int main_16_block_0_loop_OX_1_end(){
            return main_16_block_0_loop_OX_1_iter < 2;
        }

        extern volatile int main_16_block_0_loop_C_iter;

        inline void main_16_block_0_loop_C_set(){
            main_16_block_0_loop_C_iter = 0;
            main_16_input_0_dim_3->curr_size = 1.0;
            main_16_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_C_reset(){
            // main_16_block_0_loop_C_iter = 0;
            main_16_input_0_dim_3->global_idx -= 60.0;
            return 0;
        }
        inline void main_16_block_0_loop_C_update(){
            main_16_block_0_loop_C_iter += 1;
            main_16_input_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_16_input_0_dim_3->curr_size = 1.0;
            main_16_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_C_end(){
            return main_16_block_0_loop_C_iter < 60;
        }

        extern volatile int main_16_block_0_loop_OY_iter;

        inline void main_16_block_0_loop_OY_set(){
            main_16_block_0_loop_OY_iter = 0;
            main_16_input_0_dim_1->curr_size = 1.0;
            main_16_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_OY_reset(){
            // main_16_block_0_loop_OY_iter = 0;
            main_16_input_0_dim_1->global_idx -= 4.0;
            return 0;
        }
        inline void main_16_block_0_loop_OY_update(){
            main_16_block_0_loop_OY_iter += 1;
            main_16_input_0_dim_1->global_idx += 1.0;
            // update the current size of the dim
            main_16_input_0_dim_1->curr_size = 1.0;
            main_16_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_OY_end(){
            return main_16_block_0_loop_OY_iter < 4;
        }

        extern volatile int main_16_block_0_loop_OX_iter;

        inline void main_16_block_0_loop_OX_set(){
            main_16_block_0_loop_OX_iter = 0;
            main_16_input_0_dim_2->curr_size = 1.0;
            main_16_input_0_dim_2->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_OX_reset(){
            // main_16_block_0_loop_OX_iter = 0;
            main_16_input_0_dim_2->global_idx -= 2.0;
            return 0;
        }
        inline void main_16_block_0_loop_OX_update(){
            main_16_block_0_loop_OX_iter += 1;
            main_16_input_0_dim_2->global_idx += 1.0;
            // update the current size of the dim
            main_16_input_0_dim_2->curr_size = 1.0;
            main_16_input_0_dim_2->curr_max_size = 1.0;
        }
        inline int main_16_block_0_loop_OX_end(){
            return main_16_block_0_loop_OX_iter < 2;
        }


// Node Profiling
extern volatile node_stats_t main_16_stats;

#endif