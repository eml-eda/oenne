#ifndef __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_20_H__
#define __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_20_H__

#include <match/ctx.h>
#include <match/utils.h>
#include <match/types.h>

#include <pulp_platform.h>
#include <pulp_cluster.h>
#include <nodes/oenne/main_20_data.h>

// DIMS
extern const char* main_20_dims_names_[];
extern MatchDim main_20_dims_[9+1];
extern MatchDim* main_20_input_0_dim_0;
extern MatchDim* main_20_input_0_dim_1;
extern MatchDim* main_20_input_0_dim_2;
extern MatchDim* main_20_const_0_dim_0;
extern MatchDim* main_20_const_0_dim_1;
extern MatchDim* main_20_const_0_dim_2;
extern MatchDim* main_20_const_0_dim_3;
extern MatchDim* main_20_conv2d_out_h;
extern MatchDim* main_20_conv2d_out_w;
extern MatchDim* main_20_default;
extern MatchDims main_20_dims_cnt_;

// TILES
extern MatchTensorTile main_20_input_0_tiles_[8];
extern MatchTensorTile* main_20_input_0_tiles;
extern MatchTensorTile main_20_const_0_tiles_[8];
extern MatchTensorTile* main_20_const_0_tiles;
extern MatchTensorTile main_20_const_1_tiles_[4];
extern MatchTensorTile* main_20_const_1_tiles;
extern MatchTensorTile main_20_const_2_tiles_[4];
extern MatchTensorTile* main_20_const_2_tiles;
extern MatchTensorTile main_20_cast_2_out_tiles_[8];
extern MatchTensorTile* main_20_cast_2_out_tiles;


extern const char* main_20_tensors_names_[];
extern MatchTensor main_20_tensors_[5];
extern unsigned int main_20_input_0_pts[2];
extern MatchTensor* main_20_input_0;
extern unsigned int main_20_const_0_pts[2];
extern MatchTensor* main_20_const_0;
extern unsigned int main_20_const_1_pts[2];
extern MatchTensor* main_20_const_1;
extern unsigned int main_20_const_2_pts[2];
extern MatchTensor* main_20_const_2;
extern unsigned int main_20_cast_2_out_pts[2];
extern MatchTensor* main_20_cast_2_out;
extern MatchTensors main_20_tensors_cnt_;

// ops
extern const char* main_20_ops_names_[];
extern MatchOp main_20_ops_[7];
extern MatchConv2DAttrs main_20_op_conv2d_attrs_;
extern MatchConv2DAttrs* main_20_conv2d_attrs;
extern MatchOp* main_20_conv2d_op;
extern MatchCastAttrs main_20_op_cast_attrs_;
extern MatchCastAttrs* main_20_cast_attrs;
extern MatchOp* main_20_cast_op;
extern MatchMultiplyAttrs main_20_op_multiply_attrs_;
extern MatchMultiplyAttrs* main_20_multiply_attrs;
extern MatchOp* main_20_multiply_op;
extern MatchAddAttrs main_20_op_add_attrs_;
extern MatchAddAttrs* main_20_add_attrs;
extern MatchOp* main_20_add_op;
extern MatchRightShiftAttrs main_20_op_right_shift_attrs_;
extern MatchRightShiftAttrs* main_20_right_shift_attrs;
extern MatchOp* main_20_right_shift_op;
extern MatchClipAttrs main_20_op_clip_attrs_;
extern MatchClipAttrs* main_20_clip_attrs;
extern MatchOp* main_20_clip_op;
extern MatchCastAttrs main_20_op_cast_2_attrs_;
extern MatchCastAttrs* main_20_cast_2_attrs;
extern MatchOp* main_20_cast_2_op;
extern MatchOps main_20_ops_cnt_;

extern volatile MatchCtx main_20_ctx_;

extern volatile MatchCtx* main_20_ctx;

inline void main_20_update_input_0_dim_1(){
    main_20_input_0_dim_1->global_idx = 
    (1*main_20_conv2d_out_h->global_idx)
     + (1*main_20_const_0_dim_0->global_idx)
     + (-1*1)
    ;
    main_20_input_0_dim_1->curr_max_size = 
    (1*main_20_conv2d_out_h->curr_size)
     + (1*main_20_const_0_dim_0->curr_size)
     + (-1*1)
    ;
    // if input_0_dim_1 goes behind 0 it means there was padding so that shouldnt count for the size
    // same if it goes over the real size
    int max_size = (main_20_input_0_dim_1->global_idx + main_20_input_0_dim_1->curr_max_size) - main_20_input_0_dim_1->size;
    int min_size = -main_20_input_0_dim_1->global_idx;
    main_20_input_0_dim_1->curr_size = main_20_input_0_dim_1->curr_max_size - ((max_size>0?max_size:0) + (min_size>0?min_size:0));
}
inline void main_20_update_input_0_dim_2(){
    main_20_input_0_dim_2->global_idx = 
    (1*main_20_conv2d_out_w->global_idx)
     + (1*main_20_const_0_dim_1->global_idx)
     + (-1*1)
    ;
    main_20_input_0_dim_2->curr_max_size = 
    (1*main_20_conv2d_out_w->curr_size)
     + (1*main_20_const_0_dim_1->curr_size)
     + (-1*1)
    ;
    // if input_0_dim_2 goes behind 0 it means there was padding so that shouldnt count for the size
    // same if it goes over the real size
    int max_size = (main_20_input_0_dim_2->global_idx + main_20_input_0_dim_2->curr_max_size) - main_20_input_0_dim_2->size;
    int min_size = -main_20_input_0_dim_2->global_idx;
    main_20_input_0_dim_2->curr_size = main_20_input_0_dim_2->curr_max_size - ((max_size>0?max_size:0) + (min_size>0?min_size:0));
}


// loops iters counters
        extern volatile int main_20_block_0_loop_K_1_iter;

        inline void main_20_block_0_loop_K_1_set(){
            main_20_block_0_loop_K_1_iter = 0;
            main_20_const_0_dim_3->curr_size = 1.0;
            main_20_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_20_block_0_loop_K_1_reset(){
            // main_20_block_0_loop_K_1_iter = 0;
            main_20_const_0_dim_3->global_idx -= 121.0;
            return 0;
        }
        inline void main_20_block_0_loop_K_1_update(){
            main_20_block_0_loop_K_1_iter += 1;
            main_20_const_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_20_const_0_dim_3->curr_size = 1.0;
            main_20_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_20_block_0_loop_K_1_end(){
            return main_20_block_0_loop_K_1_iter < 121;
        }

        extern volatile int main_20_block_0_loop_FX_iter;

        inline void main_20_block_0_loop_FX_set(){
            main_20_block_0_loop_FX_iter = 0;
            main_20_const_0_dim_1->curr_size = 1.0;
            main_20_const_0_dim_1->curr_max_size = 1.0;
            main_20_update_input_0_dim_2();
        }
        inline int main_20_block_0_loop_FX_reset(){
            // main_20_block_0_loop_FX_iter = 0;
            main_20_const_0_dim_1->global_idx -= 3.0;
            main_20_update_input_0_dim_2();
            return 0;
        }
        inline void main_20_block_0_loop_FX_update(){
            main_20_block_0_loop_FX_iter += 1;
            main_20_const_0_dim_1->global_idx += 1.0;
            // update the current size of the dim
            main_20_const_0_dim_1->curr_size = 1.0;
            main_20_const_0_dim_1->curr_max_size = 1.0;
            main_20_update_input_0_dim_2();
        }
        inline int main_20_block_0_loop_FX_end(){
            return main_20_block_0_loop_FX_iter < 3;
        }

        extern volatile int main_20_block_0_loop_FY_iter;

        inline void main_20_block_0_loop_FY_set(){
            main_20_block_0_loop_FY_iter = 0;
            main_20_const_0_dim_0->curr_size = 1.0;
            main_20_const_0_dim_0->curr_max_size = 1.0;
            main_20_update_input_0_dim_1();
        }
        inline int main_20_block_0_loop_FY_reset(){
            // main_20_block_0_loop_FY_iter = 0;
            main_20_const_0_dim_0->global_idx -= 3.0;
            main_20_update_input_0_dim_1();
            return 0;
        }
        inline void main_20_block_0_loop_FY_update(){
            main_20_block_0_loop_FY_iter += 1;
            main_20_const_0_dim_0->global_idx += 1.0;
            // update the current size of the dim
            main_20_const_0_dim_0->curr_size = 1.0;
            main_20_const_0_dim_0->curr_max_size = 1.0;
            main_20_update_input_0_dim_1();
        }
        inline int main_20_block_0_loop_FY_end(){
            return main_20_block_0_loop_FY_iter < 3;
        }

        extern volatile int main_20_block_0_loop_OX_iter;

        inline void main_20_block_0_loop_OX_set(){
            main_20_block_0_loop_OX_iter = 0;
            main_20_conv2d_out_w->curr_size = 1.0;
            main_20_conv2d_out_w->curr_max_size = 1.0;
            main_20_update_input_0_dim_2();
        }
        inline int main_20_block_0_loop_OX_reset(){
            // main_20_block_0_loop_OX_iter = 0;
            main_20_conv2d_out_w->global_idx -= 4.0;
            main_20_update_input_0_dim_2();
            return 0;
        }
        inline void main_20_block_0_loop_OX_update(){
            main_20_block_0_loop_OX_iter += 1;
            main_20_conv2d_out_w->global_idx += 1.0;
            // update the current size of the dim
            main_20_conv2d_out_w->curr_size = 1.0;
            main_20_conv2d_out_w->curr_max_size = 1.0;
            main_20_update_input_0_dim_2();
        }
        inline int main_20_block_0_loop_OX_end(){
            return main_20_block_0_loop_OX_iter < 4;
        }

        extern volatile int main_20_block_0_loop_OY_iter;

        inline void main_20_block_0_loop_OY_set(){
            main_20_block_0_loop_OY_iter = 0;
            main_20_conv2d_out_h->curr_size = 1.0;
            main_20_conv2d_out_h->curr_max_size = 1.0;
            main_20_update_input_0_dim_1();
        }
        inline int main_20_block_0_loop_OY_reset(){
            // main_20_block_0_loop_OY_iter = 0;
            main_20_conv2d_out_h->global_idx -= 4.0;
            main_20_update_input_0_dim_1();
            return 0;
        }
        inline void main_20_block_0_loop_OY_update(){
            main_20_block_0_loop_OY_iter += 1;
            main_20_conv2d_out_h->global_idx += 1.0;
            // update the current size of the dim
            main_20_conv2d_out_h->curr_size = 1.0;
            main_20_conv2d_out_h->curr_max_size = 1.0;
            main_20_update_input_0_dim_1();
        }
        inline int main_20_block_0_loop_OY_end(){
            return main_20_block_0_loop_OY_iter < 4;
        }


// Node Profiling
extern volatile node_stats_t main_20_stats;

#endif