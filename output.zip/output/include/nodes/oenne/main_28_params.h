#ifndef __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_28_H__
#define __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_28_H__

#include <match/ctx.h>
#include <match/utils.h>
#include <match/types.h>

#include <pulp_platform.h>
#include <pulp_cluster.h>
#include <nodes/oenne/main_28_data.h>

// DIMS
extern const char* main_28_dims_names_[];
extern MatchDim main_28_dims_[3+1];
extern MatchDim* main_28_input_0_dim_0;
extern MatchDim* main_28_input_0_dim_1;
extern MatchDim* main_28_const_0_dim_0;
extern MatchDim* main_28_default;
extern MatchDims main_28_dims_cnt_;

// TILES
extern MatchTensorTile main_28_input_0_tiles_[4];
extern MatchTensorTile* main_28_input_0_tiles;
extern MatchTensorTile main_28_const_0_tiles_[4];
extern MatchTensorTile* main_28_const_0_tiles;
extern MatchTensorTile main_28_add_arg_1_tiles_[4];
extern MatchTensorTile* main_28_add_arg_1_tiles;
extern MatchTensorTile main_28_add_out_tiles_[4];
extern MatchTensorTile* main_28_add_out_tiles;


extern const char* main_28_tensors_names_[];
extern MatchTensor main_28_tensors_[4];
extern unsigned int main_28_input_0_pts[2];
extern MatchTensor* main_28_input_0;
extern unsigned int main_28_const_0_pts[2];
extern MatchTensor* main_28_const_0;
extern unsigned int main_28_add_arg_1_pts[2];
extern MatchTensor* main_28_add_arg_1;
extern unsigned int main_28_add_out_pts[2];
extern MatchTensor* main_28_add_out;
extern MatchTensors main_28_tensors_cnt_;

// ops
extern const char* main_28_ops_names_[];
extern MatchOp main_28_ops_[3];
extern MatchDenseAttrs main_28_op_dense_attrs_;
extern MatchDenseAttrs* main_28_dense_attrs;
extern MatchOp* main_28_dense_op;
extern MatchCastAttrs main_28_op_cast_attrs_;
extern MatchCastAttrs* main_28_cast_attrs;
extern MatchOp* main_28_cast_op;
extern MatchAddAttrs main_28_op_add_attrs_;
extern MatchAddAttrs* main_28_add_attrs;
extern MatchOp* main_28_add_op;
extern MatchOps main_28_ops_cnt_;

extern volatile MatchCtx main_28_ctx_;

extern volatile MatchCtx* main_28_ctx;



// loops iters counters
        extern volatile int main_28_block_0_loop_K_1_iter;

        inline void main_28_block_0_loop_K_1_set(){
            main_28_block_0_loop_K_1_iter = 0;
            main_28_const_0_dim_0->curr_size = 5.0;
            main_28_const_0_dim_0->curr_max_size = 5.0;
        }
        inline int main_28_block_0_loop_K_1_reset(){
            // main_28_block_0_loop_K_1_iter = 0;
            main_28_const_0_dim_0->global_idx -= 10.0;
            return 0;
        }
        inline void main_28_block_0_loop_K_1_update(){
            main_28_block_0_loop_K_1_iter += 1;
            main_28_const_0_dim_0->global_idx += 5.0;
            // update the current size of the dim
            main_28_const_0_dim_0->curr_size = 5.0;
            main_28_const_0_dim_0->curr_max_size = 5.0;
        }
        inline int main_28_block_0_loop_K_1_end(){
            return main_28_block_0_loop_K_1_iter < 2;
        }

        extern volatile int main_28_block_0_loop_C_iter;

        inline void main_28_block_0_loop_C_set(){
            main_28_block_0_loop_C_iter = 0;
            main_28_input_0_dim_1->curr_size = 1.0;
            main_28_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_28_block_0_loop_C_reset(){
            // main_28_block_0_loop_C_iter = 0;
            main_28_input_0_dim_1->global_idx -= 209.0;
            return 0;
        }
        inline void main_28_block_0_loop_C_update(){
            main_28_block_0_loop_C_iter += 1;
            main_28_input_0_dim_1->global_idx += 1.0;
            // update the current size of the dim
            main_28_input_0_dim_1->curr_size = 1.0;
            main_28_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_28_block_0_loop_C_end(){
            return main_28_block_0_loop_C_iter < 209;
        }

        extern volatile int main_28_block_0_loop_K_iter;

        inline void main_28_block_0_loop_K_set(){
            main_28_block_0_loop_K_iter = 0;
            main_28_const_0_dim_0->curr_size = 1.0;
            main_28_const_0_dim_0->curr_max_size = 1.0;
        }
        inline int main_28_block_0_loop_K_reset(){
            // main_28_block_0_loop_K_iter = 0;
            main_28_const_0_dim_0->global_idx -= 5.0;
            return 0;
        }
        inline void main_28_block_0_loop_K_update(){
            main_28_block_0_loop_K_iter += 1;
            main_28_const_0_dim_0->global_idx += 1.0;
            // update the current size of the dim
            main_28_const_0_dim_0->curr_size = 1.0;
            main_28_const_0_dim_0->curr_max_size = 1.0;
        }
        inline int main_28_block_0_loop_K_end(){
            return main_28_block_0_loop_K_iter < 5;
        }


// Node Profiling
extern volatile node_stats_t main_28_stats;

#endif