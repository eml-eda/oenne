#ifndef __MATCH_NODE_DATA_tvmgen_oenne_match_main_8_H__
#define __MATCH_NODE_DATA_tvmgen_oenne_match_main_8_H__

extern int8_t* main_8_const_0_data;
extern int* main_8_const_1_data;
extern int* main_8_const_2_data;
extern int* main_8_right_shift_arg_1_data;

#endif