#ifndef __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_24_H__
#define __MATCH_NODE_PARAMS_tvmgen_oenne_match_main_24_H__

#include <match/ctx.h>
#include <match/utils.h>
#include <match/types.h>

#include <pulp_platform.h>
#include <pulp_cluster.h>
#include <nodes/oenne/main_24_data.h>

// DIMS
extern const char* main_24_dims_names_[];
extern MatchDim main_24_dims_[7+1];
extern MatchDim* main_24_input_0_dim_0;
extern MatchDim* main_24_input_0_dim_1;
extern MatchDim* main_24_input_0_dim_2;
extern MatchDim* main_24_input_0_dim_3;
extern MatchDim* main_24_const_0_dim_0;
extern MatchDim* main_24_const_0_dim_1;
extern MatchDim* main_24_const_0_dim_3;
extern MatchDim* main_24_default;
extern MatchDims main_24_dims_cnt_;

// TILES
extern MatchTensorTile main_24_input_0_tiles_[8];
extern MatchTensorTile* main_24_input_0_tiles;
extern MatchTensorTile main_24_const_0_tiles_[8];
extern MatchTensorTile* main_24_const_0_tiles;
extern MatchTensorTile main_24_const_1_tiles_[4];
extern MatchTensorTile* main_24_const_1_tiles;
extern MatchTensorTile main_24_const_2_tiles_[4];
extern MatchTensorTile* main_24_const_2_tiles;
extern MatchTensorTile main_24_cast_2_out_tiles_[8];
extern MatchTensorTile* main_24_cast_2_out_tiles;


extern const char* main_24_tensors_names_[];
extern MatchTensor main_24_tensors_[5];
extern unsigned int main_24_input_0_pts[2];
extern MatchTensor* main_24_input_0;
extern unsigned int main_24_const_0_pts[2];
extern MatchTensor* main_24_const_0;
extern unsigned int main_24_const_1_pts[2];
extern MatchTensor* main_24_const_1;
extern unsigned int main_24_const_2_pts[2];
extern MatchTensor* main_24_const_2;
extern unsigned int main_24_cast_2_out_pts[2];
extern MatchTensor* main_24_cast_2_out;
extern MatchTensors main_24_tensors_cnt_;

// ops
extern const char* main_24_ops_names_[];
extern MatchOp main_24_ops_[7];
extern MatchConv2DAttrs main_24_op_conv2d_attrs_;
extern MatchConv2DAttrs* main_24_conv2d_attrs;
extern MatchOp* main_24_conv2d_op;
extern MatchCastAttrs main_24_op_cast_attrs_;
extern MatchCastAttrs* main_24_cast_attrs;
extern MatchOp* main_24_cast_op;
extern MatchMultiplyAttrs main_24_op_multiply_attrs_;
extern MatchMultiplyAttrs* main_24_multiply_attrs;
extern MatchOp* main_24_multiply_op;
extern MatchAddAttrs main_24_op_add_attrs_;
extern MatchAddAttrs* main_24_add_attrs;
extern MatchOp* main_24_add_op;
extern MatchRightShiftAttrs main_24_op_right_shift_attrs_;
extern MatchRightShiftAttrs* main_24_right_shift_attrs;
extern MatchOp* main_24_right_shift_op;
extern MatchClipAttrs main_24_op_clip_attrs_;
extern MatchClipAttrs* main_24_clip_attrs;
extern MatchOp* main_24_clip_op;
extern MatchCastAttrs main_24_op_cast_2_attrs_;
extern MatchCastAttrs* main_24_cast_2_attrs;
extern MatchOp* main_24_cast_2_op;
extern MatchOps main_24_ops_cnt_;

extern volatile MatchCtx main_24_ctx_;

extern volatile MatchCtx* main_24_ctx;



// loops iters counters
        extern volatile int main_24_block_0_loop_K_2_iter;

        inline void main_24_block_0_loop_K_2_set(){
            main_24_block_0_loop_K_2_iter = 0;
            main_24_const_0_dim_3->curr_size = 19.0;
            main_24_const_0_dim_3->curr_max_size = 19.0;
        }
        inline int main_24_block_0_loop_K_2_reset(){
            // main_24_block_0_loop_K_2_iter = 0;
            main_24_const_0_dim_3->global_idx -= 209.0;
            return 0;
        }
        inline void main_24_block_0_loop_K_2_update(){
            main_24_block_0_loop_K_2_iter += 1;
            main_24_const_0_dim_3->global_idx += 19.0;
            // update the current size of the dim
            main_24_const_0_dim_3->curr_size = 19.0;
            main_24_const_0_dim_3->curr_max_size = 19.0;
        }
        inline int main_24_block_0_loop_K_2_end(){
            return main_24_block_0_loop_K_2_iter < 11;
        }

        extern volatile int main_24_block_0_loop_K_1_iter;

        inline void main_24_block_0_loop_K_1_set(){
            main_24_block_0_loop_K_1_iter = 0;
            main_24_const_0_dim_3->curr_size = 1.0;
            main_24_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_K_1_reset(){
            // main_24_block_0_loop_K_1_iter = 0;
            main_24_const_0_dim_3->global_idx -= 19.0;
            return 0;
        }
        inline void main_24_block_0_loop_K_1_update(){
            main_24_block_0_loop_K_1_iter += 1;
            main_24_const_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_24_const_0_dim_3->curr_size = 1.0;
            main_24_const_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_K_1_end(){
            return main_24_block_0_loop_K_1_iter < 19;
        }

        extern volatile int main_24_block_0_loop_OX_1_iter;

        inline void main_24_block_0_loop_OX_1_set(){
            main_24_block_0_loop_OX_1_iter = 0;
            main_24_input_0_dim_2->curr_size = 2.0;
            main_24_input_0_dim_2->curr_max_size = 2.0;
        }
        inline int main_24_block_0_loop_OX_1_reset(){
            // main_24_block_0_loop_OX_1_iter = 0;
            main_24_input_0_dim_2->global_idx -= 4.0;
            return 0;
        }
        inline void main_24_block_0_loop_OX_1_update(){
            main_24_block_0_loop_OX_1_iter += 1;
            main_24_input_0_dim_2->global_idx += 2.0;
            // update the current size of the dim
            main_24_input_0_dim_2->curr_size = 2.0;
            main_24_input_0_dim_2->curr_max_size = 2.0;
        }
        inline int main_24_block_0_loop_OX_1_end(){
            return main_24_block_0_loop_OX_1_iter < 2;
        }

        extern volatile int main_24_block_0_loop_C_iter;

        inline void main_24_block_0_loop_C_set(){
            main_24_block_0_loop_C_iter = 0;
            main_24_input_0_dim_3->curr_size = 1.0;
            main_24_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_C_reset(){
            // main_24_block_0_loop_C_iter = 0;
            main_24_input_0_dim_3->global_idx -= 121.0;
            return 0;
        }
        inline void main_24_block_0_loop_C_update(){
            main_24_block_0_loop_C_iter += 1;
            main_24_input_0_dim_3->global_idx += 1.0;
            // update the current size of the dim
            main_24_input_0_dim_3->curr_size = 1.0;
            main_24_input_0_dim_3->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_C_end(){
            return main_24_block_0_loop_C_iter < 121;
        }

        extern volatile int main_24_block_0_loop_OY_iter;

        inline void main_24_block_0_loop_OY_set(){
            main_24_block_0_loop_OY_iter = 0;
            main_24_input_0_dim_1->curr_size = 1.0;
            main_24_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_OY_reset(){
            // main_24_block_0_loop_OY_iter = 0;
            main_24_input_0_dim_1->global_idx -= 4.0;
            return 0;
        }
        inline void main_24_block_0_loop_OY_update(){
            main_24_block_0_loop_OY_iter += 1;
            main_24_input_0_dim_1->global_idx += 1.0;
            // update the current size of the dim
            main_24_input_0_dim_1->curr_size = 1.0;
            main_24_input_0_dim_1->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_OY_end(){
            return main_24_block_0_loop_OY_iter < 4;
        }

        extern volatile int main_24_block_0_loop_OX_iter;

        inline void main_24_block_0_loop_OX_set(){
            main_24_block_0_loop_OX_iter = 0;
            main_24_input_0_dim_2->curr_size = 1.0;
            main_24_input_0_dim_2->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_OX_reset(){
            // main_24_block_0_loop_OX_iter = 0;
            main_24_input_0_dim_2->global_idx -= 2.0;
            return 0;
        }
        inline void main_24_block_0_loop_OX_update(){
            main_24_block_0_loop_OX_iter += 1;
            main_24_input_0_dim_2->global_idx += 1.0;
            // update the current size of the dim
            main_24_input_0_dim_2->curr_size = 1.0;
            main_24_input_0_dim_2->curr_max_size = 1.0;
        }
        inline int main_24_block_0_loop_OX_end(){
            return main_24_block_0_loop_OX_iter < 2;
        }


// Node Profiling
extern volatile node_stats_t main_24_stats;

#endif