#ifndef __MATCH_NODE_DATA_tvmgen_oenne_match_main_12_H__
#define __MATCH_NODE_DATA_tvmgen_oenne_match_main_12_H__

extern int8_t* main_12_const_0_data;
extern int* main_12_const_1_data;
extern int* main_12_const_2_data;
extern int* main_12_right_shift_arg_1_data;

#endif